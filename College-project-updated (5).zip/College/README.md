# Maharashtra Tourism Planner

A simple college mini-project built with Java 21, Spring Boot, Maven, Spring Data JPA, H2, HTML, CSS and vanilla JavaScript. It helps users explore Maharashtra destinations, find nearby places, build a road route, estimate trip costs, and create a timed itinerary.

> **Important demo-data note:** The hotel ideas and rates in destination guides are illustrative sample data, not verified properties or live prices. The route page can open a date-specific Booking.com search; inventory, price, terms and booking are confirmed on the provider’s page. This app does not book hotels or transport.

## Features

- Search 50 seeded Maharashtra destinations with case-insensitive partial search and suggestions.
- Show a distinct locally stored destination photograph on each of the 50 cards.
- Keep Wikimedia Commons author and license credits in the in-app **Photo credits** page.
- Use a real Bhimashankar Wildlife Sanctuary landscape in the homepage hero, with photographer and CC BY-SA attribution shown on-page and in the photo credits.
- View destination details and at least six attraction/guide stops for every seeded destination.
- View illustrative budget, standard and premium stay-planning bands for every seeded destination; these are not verified properties or live listings.
- Calculate accommodation, food, transportation and miscellaneous costs in INR.
- Generate a timed 1–3 day itinerary with visit durations, estimated transfers, lunch/rest breaks and a relaxed 9 AM–6 PM planning window.
- Open a separate nearby-attractions page from a destination guide, search mapped places around a destination/custom place/current location, and select up to eight stops.
- Build a route that repeatedly visits the remaining stop with the shortest estimated road travel time; in car-free areas, show a clearly labelled straight-line walking estimate instead of a false zero-length drive.
- Inspect route geometry, leg estimates and stop order on a map, then open driving or walking directions in Google Maps.
- Use date- and guest-specific Booking.com search links for current stay inventory/prices. The website deliberately does not invent in-app prices without an approved partner API.
- Friendly unknown destination and error states.
- Register an account, sign in, restore an active session, and sign out.
- Responsive interface; frontend served by Spring Boot from the same origin.
- Persistent local H2 database; an idempotent startup backfill enriches existing databases without resetting user data.

## Technology

- Java 21
- Spring Boot 3.5.6
- Maven
- Spring Web, Spring Data JPA, Spring Security, Bean Validation
- H2 file database
- HTML5, CSS3, JavaScript, locally bundled Leaflet map library
- JUnit 5 / Spring Boot Test

## Prerequisites

- JDK 21 installed and available on `PATH` (`java -version` should show 21).
- Maven 3.8+ installed and available on `PATH`.
- Internet access on the first build so Maven can download dependencies.

A Maven Wrapper is not included because it could not be generated and verified in the build environment used to prepare this project. Install Maven, or generate a wrapper locally with `mvn wrapper:wrapper` if your Maven installation supports it.

## Run in IntelliJ IDEA

1. Install a JDK 21 distribution (for example, Microsoft OpenJDK 21 or Temurin 21). JDK 17 is not sufficient for this project.
2. Extract the project ZIP and open the `College` folder — the folder containing `pom.xml` — in IntelliJ IDEA.
3. Go to **File → Project Structure → Project** and set **SDK** to JDK 21. If it is missing, choose **Add SDK → JDK** and select the JDK 21 installation directory.
4. In **File → Project Structure → Modules**, select `tourism-planner` and set **Module SDK** to **Project SDK (21)** or directly select JDK 21. Do not leave it assigned to Microsoft OpenJDK 17.
5. Go to **Settings → Build, Execution, Deployment → Build Tools → Maven → Runner** and set **JRE** to the project JDK (21). Check Maven importing uses the project JDK as well.
6. In the Maven tool window, click **Reload All Maven Projects**.
7. Run `java -version` in the IntelliJ terminal and confirm it reports version 21. Then run `TourismPlannerApplication.java` or use the terminal command below.
8. Open **http://localhost:8080**.

The Maven configuration explicitly targets Java 21 through `java.version`, `maven.compiler.release`, and the compiler plugin's `release` setting. These settings do not install JDK 21 or override an IntelliJ module that is still assigned to JDK 17; configure the IDE SDK as described above.

## Run from terminal

From the folder containing `pom.xml`:

```bash
mvn spring-boot:run
```

Build a runnable JAR:

```bash
mvn clean package
java -jar target/tourism-planner-1.0.0.jar
```

Run automated tests:

```bash
mvn test
```

## H2 console

- URL: **http://localhost:8080/h2-console**
- JDBC URL: `jdbc:h2:file:./data/tourismdb`
The database uses a local file-based H2 URL. Do not add `AUTO_SERVER=TRUE` alongside `DB_CLOSE_ON_EXIT=FALSE` for the bundled H2 version, because that option combination is unsupported.
- User: `sa`
- Password: leave blank

The database files are created under the `data` directory relative to the working directory. Stop the app before moving or deleting those files. To reset demo data, stop the app and delete the local `data` directory; it will be recreated at startup.

## API examples

- `GET /api/auth/csrf` — obtain the CSRF token required for state-changing requests.
- `POST /api/auth/register` — create an account and start a session; request fields: `name`, `email`, `password`.
- `POST /api/auth/login` — sign in with `email` and `password`.
- `GET /api/auth/me` — return the signed-in account, or `401` when no session is active.
- `POST /api/auth/logout` — end the current session.

The browser keeps the session in an HTTP-only cookie. For each `POST`, send the token returned by `/api/auth/csrf` as `X-XSRF-TOKEN` and preserve the CSRF cookie. The frontend handles this automatically.
- `GET /api/destinations` — list all seeded destinations.
- `GET /api/destinations/search?query=math` — partial, case-insensitive search; no matches returns `[]`.
- `GET /api/destinations/by-name?name=Matheran` — look up a destination by exact name, case-insensitively; unknown name returns 404.
- `GET /api/destinations/3` — get destination by ID (IDs depend on local database state).
- `GET /api/destinations/3/attractions` — attraction list.
- `GET /api/destinations/3/hotels` — sample hotel list.
- `GET /api/maps/geocode?query=Matheran%2C%20Maharashtra` — user-triggered place lookup, restricted to Maharashtra; results are cached.
- `GET /api/maps/nearby?latitude=18.99&longitude=73.27&radiusKm=5` — nearby OpenStreetMap places within the bounded 3–10 km radius, sorted by straight-line distance; cached for six hours.
- `POST /api/maps/route` — order up to eight nearby stops by shortest remaining road travel time when OSRM returns a usable road network. If roads collapse to the same point, return a clearly labelled straight-line walking-time estimate instead. Like other state-changing API requests, send the CSRF token.
- `GET /api/maps/tiles/{z}/{x}/{y}.png` — same-origin, disk-cached OpenStreetMap tile proxy with seven-day browser caching.
- `GET /api/destinations/3/itinerary?days=2` — timed itinerary; `days` must be 1, 2 or 3. Response includes day start/end times and activities with start/end, visit duration, transfer estimate and rest breaks.
- `POST /api/budget/calculate` — calculate budget.

Budget request example:

```json
{
  "travellers": 2,
  "days": 2,
  "hotelCategory": "standard",
  "rooms": 1,
  "transportation": 1500,
  "dailyFoodPerPerson": 500,
  "miscellaneous": 500
}
```

For this example, accommodation is ₹2,500, food is ₹2,000, transport is ₹1,500, miscellaneous is ₹500, and the estimated total is ₹6,500 (₹3,250 per person). One-day trips use zero hotel nights.

## Project structure

```text
java/com/maharashtra/tourism/       # Maven sourceDirectory configured in pom.xml
  config/       Sample data initialization
  controller/   REST API endpoints, including map/route APIs
  dto/          Budget, auth, map and route request/response models
  entity/       User, Destination, Attraction and Hotel JPA entities
  exception/    Central API error handling
  repository/   JPA data access interfaces
  service/      Search, itinerary, budget and cached map/route logic
src/main/resources/
  application.properties
static/         index.html, route-planner.html, stylesheets and browser scripts
  vendor/leaflet/  Locally bundled Leaflet library and licence
  images/destinations/  Locally stored destination photos and per-file credits
docs/            External data-source, attribution and usage notes
scripts/         Photo asset collection utility
src/test/java/  Spring Boot tests
```

The photo collector can be rerun with Python 3 after installing `scripts/requirements.txt`:

```bash
python3 -m pip install -r scripts/requirements.txt
python3 scripts/download_destination_images.py
```

## Notes and limitations

- Nearby map lookups use user-triggered Nominatim geocoding and Overpass POI queries; route distances use the public OSRM demo service. Requests are bounded, cached, and made server-side. Map providers can be switched in `application.properties` (`tourism.map.*`). Public services can be busy and have no uptime guarantee. See `docs/TRAVEL_DATA_SOURCES.md` for sources and policies.
- The default OSRM demo is restricted to reasonable non-commercial use and at most one request per second. The tile proxy sends a stable app User-Agent and page Referer, stores downloaded tiles under `data/osm-tiles`, and returns a seven-day browser cache. Do not use public map services as an unbounded production backend; switch to an appropriate provider or operate your own service before scaling.
- Destination guides include curated sample stop suggestions for all 50 seeded places. Opening hours, entry fees, permits, road conditions and seasonal access are not live-verified; check official/local guidance.
- Stay ideas and hotel prices in destination guides are illustrative planning bands, not verified listings. The separate route page redirects to a date-specific Booking.com search for current provider inventory; price, availability, taxes, room terms and booking are handled there. In-page live rates require approved partner API access and server-side credentials; none are configured.
- Road route ordering uses a nearest-next heuristic based on estimated drive time, not a globally optimal itinerary; estimates exclude live traffic, closures, opening hours, permits and weather. If no usable drivable route exists (for example, car-free Matheran viewpoints), the API falls back to straight-line distances and a conservative 3 km/h walking-time estimate. That is not a mapped pedestrian path or turn-by-turn instruction; Google Maps walking directions are offered separately for checking. Confirm local paths/access before travelling.
- Timed 1–3 day itineraries use estimated visit and transfer durations, have meal/rest breaks and avoid scheduling beyond about 6 PM; the planner may show fewer visits rather than overfill a day.
- H2 console is enabled for local development only. Do not expose this demo console to a public network.
- Passwords are stored as BCrypt hashes; authentication uses server-side sessions and CSRF protection. Sessions expire after 30 minutes of inactivity.
- Password reset email is not configured because this project has no email service. Use HTTPS before handling real user credentials, and do not expose the local H2 console publicly.
- Destination images are locally bundled from Wikimedia Commons. Each image has separate reuse terms; see the in-app Photo credits link or `static/images/destinations/CREDITS.md` and retain those credits when reusing the photos.
- The site does not process payments, reservations or bookings.
