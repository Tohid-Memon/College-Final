#!/usr/bin/env python3
"""Download one locally hosted, attributable Wikimedia Commons photo per seeded destination."""
from __future__ import annotations

import html
import json
import re
import sys
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.parse import quote, unquote, urlparse

import requests
from PIL import Image, ImageOps
from io import BytesIO

ROOT = Path(__file__).resolve().parents[1]
SEED = ROOT / "java/com/maharashtra/tourism/config/SampleDataInitializer.java"
OUT = ROOT / "static/images/destinations"
API = "https://commons.wikimedia.org/w/api.php"
HEADERS = {"User-Agent": "MaharashtraTrails/1.0 (educational tourism project; photo credits included)"}

HERO_CREDIT = {
    "destination": "Homepage hero — Bhimashankar Wildlife Sanctuary",
    "filename": "hero-bhimashankar.jpg",
    "local_path": "/images/hero-bhimashankar.jpg",
    "title": "File:Monsoon Maharashtra India Rain Landscape (1) 16.jpg",
    "artist": "Nikhil More",
    "license": "CC BY-SA 4.0",
    "license_url": "https://creativecommons.org/licenses/by-sa/4.0/",
    "source_url": "https://commons.wikimedia.org/wiki/File:Monsoon_Maharashtra_India_Rain_Landscape_(1)_16.jpg",
    "adaptation": "Responsive crop and CSS gradient overlay applied.",
}

# Specific local landmarks make city/region cards more recognizable than generic file searches.
ALIASES = {
    "Mumbai": "Gateway of India Mumbai",
    "Pune": "Shaniwar Wada Pune",
    "Nashik": "Nashik Maharashtra city",
    "Alibaug": "Alibaug beach sun set scene",
    "Ratnagiri": "Ratnadurg Fort - panoramio",
    "Malvan": "Sindhudurg Fort Malvan Maharashtra",
    "Bhandardara": "Bhandardara lake Maharashtra",
    "Kolhapur": "Mahalaxmi Temple Kolhapur",
    "Nagpur": "Deekshabhoomi Nagpur",
    "Amravati": "Amravati Maharashtra city",
    "Chhatrapati Sambhajinagar": "Bibi Ka Maqbara Aurangabad Maharashtra",
    "Ajanta Caves": "Ajanta Caves Maharashtra",
    "Ellora Caves": "Ellora Caves Maharashtra",
    "Tadoba-Andhari Tiger Reserve": "Tadoba Andhari Tiger Reserve Maharashtra",
    "Pench National Park - Maharashtra": "Pench National Park India Maharashtra",
    "Shani Shingnapur": "Shani Shingnapur temple Maharashtra",
    "Bhimashankar": "Bhimashankar Temple Maharashtra",
    "Trimbakeshwar": "Trimbakeshwar Temple Nashik Maharashtra",
    "Torna Fort": "Torna Fort Pune Maharashtra",
    "Raigad Fort": "Raigad Fort Maharashtra",
    "Pratapgad Fort": "Pratapgad Fort Maharashtra",
    "Sinhagad Fort": "Sinhagad Fort Pune",
    "Devkund Waterfall": "Devkund Waterfall Maharashtra",
    "Lonar Lake": "Lonar Lake Maharashtra",
    "Sawantwadi": "Sawantwadi Palace Maharashtra",
    "Akkalkot": "Swami Samarth Akkalkot",
    "Nanded": "Hazur Sahib Nanded Maharashtra",
    "Tuljapur": "Tulja Bhavani Temple Tuljapur",
    "Pandharpur": "Vitthal temple Pandharpur Maharashtra",
    "Solapur": "Siddheshwar temple Solapur Maharashtra",
    "Wardha": "Sevagram Ashram Wardha",
    "Melghat": "Melghat Tiger Reserve Maharashtra",
    "Chikhaldara": "Chikhaldara Maharashtra hill station",
    "Dapoli": "Dapoli beach Maharashtra",
    "Diveagar": "Diveagar beach India",
    "Kamshet": "Kamshet Maharashtra paragliding",
    "Lavasa": "Lavasa Maharashtra lake city",
}
PREFERRED_TITLES = {
    "Alibaug": "File:Alibaug beach sun set scene.jpg",
    "Ratnagiri": "File:Ratnadurg Fort - panoramio.jpg",
    "Diveagar": "File:Diveagar beach.jpg",
    "Tuljapur": "File:Indien2012 1215 Tuljapur Bhavani Temple Eingangstor.jpg",
}

BAD_TITLE = re.compile(r"\b(map|locator|logo|flag|coat of arms|diagram|plan of|route map|satellite view|taluka)\b", re.I)
IMAGE_EXTS = {"jpg", "jpeg", "png", "webp", "tif", "tiff"}


def slugify(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]+", "-", value.lower())).strip("-")


def destinations() -> list[str]:
    text = SEED.read_text(encoding="utf-8")
    block = text.split("String[][] rows={", 1)[1].split("\n  };", 1)[0]
    names = re.findall(r'^\s*\{"([^\"]+)"\s*,', block, flags=re.M)
    if len(names) != 50:
        raise RuntimeError(f"Expected 50 seeded destinations, found {len(names)}")
    return names


def clean(value: str) -> str:
    value = re.sub(r"<[^>]*>", " ", html.unescape(value or ""))
    return re.sub(r"\s+", " ", value).strip()


def terms(query: str) -> list[str]:
    stop = {"maharashtra", "india", "the", "of", "and", "in", "for", "national", "park", "fort", "caves", "lake", "beach", "waterfall", "reserve"}
    return [x.lower() for x in re.findall(r"[a-z0-9]+", query) if len(x) > 2 and x.lower() not in stop]


def get_with_retry(url: str, *, params: dict | None = None, timeout: int = 40) -> requests.Response:
    for attempt in range(7):
        response = requests.get(url, params=params, headers=HEADERS, timeout=timeout)
        if response.status_code not in {429, 500, 502, 503, 504}:
            response.raise_for_status()
            return response
        retry_after = response.headers.get("Retry-After")
        delay = min(float(retry_after), 30) if retry_after and retry_after.isdigit() else min(3 * (attempt + 1), 18)
        print(f"Wikimedia returned HTTP {response.status_code}; retrying in {delay:g}s", file=sys.stderr)
        time.sleep(delay)
    response.raise_for_status()
    return response


def search_commons(destination: str, query: str) -> list[dict]:
    params = {
        "action": "query", "generator": "search",
        "gsrsearch": "filetype:bitmap " + query,
        "gsrnamespace": 6, "gsrlimit": 18,
        "prop": "imageinfo", "iiprop": "url|size|mime|extmetadata",
        # The cards are compact; use Commons' thumbnail CDN rather than direct originals.
        "iiurlwidth": 480, "format": "json", "formatversion": 2,
    }
    response = get_with_retry(API, params=params, timeout=45)
    pages = response.json().get("query", {}).get("pages", [])
    scored = []
    qterms = terms(query)
    dterms = terms(destination)
    for order, page in enumerate(pages):
        infos = page.get("imageinfo", [])
        if not infos:
            continue
        info = infos[0]
        title = page.get("title", "")
        suffix = title.rsplit(".", 1)[-1].lower()
        if suffix not in IMAGE_EXTS or not info.get("thumburl"):
            continue
        width, height = int(info.get("width", 0)), int(info.get("height", 0))
        if width < 600 or height < 350 or not (0.62 <= width / max(height, 1) <= 2.8):
            continue
        extmeta = info.get("extmetadata", {})
        license_name = clean(extmeta.get("LicenseShortName", {}).get("value", "")) or "License details on source page"
        license_l = license_name.lower()
        if not any(token in license_l for token in ("cc", "public domain", "no restrictions", "gfdl", "free art")):
            continue
        title_l = title.lower()
        if BAD_TITLE.search(title):
            continue
        score = 0
        for token in qterms:
            if token in title_l:
                score += 5 if len(token) > 4 else 2
        for token in dterms:
            if token in title_l:
                score += 8 if len(token) > 4 else 3
        if destination.lower() in title_l:
            score += 30
        if query.lower() in title_l:
            score += 22
        # Search order is a tie-breaker; exact and near-exact filenames outrank tangential matches.
        score -= order * 0.03
        # Prefer landscape photos, but don't discard a legitimate portrait-oriented place photo.
        score += min(width / max(height, 1), 1.7)
        scored.append((score, page, info, extmeta, license_name))
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored


def get_candidates(destination: str) -> list[dict]:
    queries = [ALIASES.get(destination, destination + " Maharashtra"), destination]
    if destination not in ALIASES:
        queries.append(destination)
    candidates: dict[str, dict] = {}
    for query in dict.fromkeys(queries):
        try:
            ranked = search_commons(destination, query)
        except Exception as error:
            print(f"WARN search {destination!r} ({query!r}): {error}", file=sys.stderr)
            continue
        for score, page, info, extmeta, license_name in ranked:
            title = page["title"]
            if title not in candidates:
                candidates[title] = {
                    "destination": destination,
                    "score": score,
                    "title": title,
                    "thumbnail_url": info["thumburl"],
                    "source_url": "https://commons.wikimedia.org/wiki/" + quote(title.replace(" ", "_"), safe=":/()!,.-_"),
                    "license": license_name,
                    "license_url": clean(extmeta.get("LicenseUrl", {}).get("value", "")),
                    "artist": clean(extmeta.get("Artist", {}).get("value", "")),
                    "credit": clean(extmeta.get("Attribution", {}).get("value", "")),
                    "description": clean(extmeta.get("ImageDescription", {}).get("value", "")),
                    "width": int(info.get("width", 0)),
                    "height": int(info.get("height", 0)),
                }
        # Once we have an exact image title match, there's little value in a broader alternative query.
        if any(destination.lower() in c["title"].lower() for c in candidates.values()):
            break
        time.sleep(0.12)
    preferred = PREFERRED_TITLES.get(destination)
    if preferred:
        for candidate in candidates.values():
            if candidate["title"] == preferred:
                candidate["score"] = 1_000_000
                break
    return sorted(candidates.values(), key=lambda c: c["score"], reverse=True)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    names = destinations()
    found: dict[str, list[dict]] = {}
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = {pool.submit(get_candidates, name): name for name in names}
        for future in as_completed(futures):
            name = futures[future]
            found[name] = future.result()
            top = found[name][0] if found[name] else None
            if top:
                print(f"{name}: {top['title']} [{top['license']}]")
            else:
                print(f"MISSING: {name}")

    used_titles: set[str] = set()
    selected: dict[str, dict] = {}
    missing = []
    for name in names:
        choice = next((c for c in found[name] if c["title"] not in used_titles), None)
        if choice is None:
            missing.append(name)
            continue
        used_titles.add(choice["title"])
        selected[name] = choice
    if missing:
        raise RuntimeError("No distinct suitably licensed Commons photos for: " + ", ".join(missing))

    for name in names:
        record = selected[name]
        filename = slugify(name) + ".jpg"
        output_path = OUT / filename
        if not output_path.exists() or output_path.stat().st_size < 5000:
            time.sleep(0.4)
            response = get_with_retry(record["thumbnail_url"], timeout=70)
            image = Image.open(BytesIO(response.content))
            image = ImageOps.exif_transpose(image).convert("RGB")
            # Preserve a generous landscape thumbnail while controlling project/archive size.
            image.thumbnail((1200, 850), Image.Resampling.LANCZOS)
            image.save(output_path, "JPEG", quality=86, optimize=True, progressive=True)
        else:
            image = Image.open(output_path)
        image = Image.open(output_path)
        record["filename"] = filename
        record["local_path"] = "/images/destinations/" + filename
        record["saved_width"], record["saved_height"] = image.size
        print(f"SAVED {filename} ({image.width}x{image.height})")

    all_credits = list(selected.values()) + [HERO_CREDIT]
    (OUT / "credits.json").write_text(json.dumps(all_credits, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# Destination and hero photo credits", "",
        "Destination cards and the homepage hero use locally stored photographs from Wikimedia Commons. Photo authors and licensing vary by file; please retain these credits when reusing the project.", "",
        "| Destination | File / author | License | Source |", "|---|---|---|---|",
    ]
    for name in names:
        c = selected[name]
        author = c["artist"] or c["credit"] or "Author as listed on Commons"
        lic = f"[{c['license']}]({c['license_url']})" if c["license_url"] else c["license"]
        lines.append(f"| {name} | {c['filename']} — {author.replace('|', '\\|')} | {lic} | [Commons file page]({c['source_url']}) |")
    hero_license = f"[{HERO_CREDIT['license']}]({HERO_CREDIT['license_url']})"
    lines.append(f"| Homepage hero — Bhimashankar | {HERO_CREDIT['filename']} — {HERO_CREDIT['artist']} | {hero_license} | [Commons file page]({HERO_CREDIT['source_url']}) |")
    lines.extend(["", f"The hero photo adaptation uses a responsive crop and CSS gradient overlay, as noted on the source credit page."])
    (OUT / "CREDITS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    credits_html = [
        "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">",
        "<title>Destination Photo Credits | Maharashtra Trails</title><style>",
        "*{box-sizing:border-box}body{margin:0;background:#f7f6ef;color:#20352f;font:16px/1.55 Arial,sans-serif}",
        "main{max-width:1050px;margin:0 auto;padding:40px 22px 70px}a{color:#28664e}h1{font-size:2rem}p{color:#64746a}",
        "ul{list-style:none;padding:0;display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}",
        "li{background:#fffef9;border:1px solid #e5e7dc;border-radius:10px;padding:16px}li strong{display:block;margin-bottom:6px}",
        ".back{display:inline-block;margin:0 0 20px}.license{font-size:.9rem;color:#58685e}</style></head><body><main>",
        "<a class=\"back\" href=\"index.html#destinations\">← Back to destinations</a>",
        "<h1>Photo credits</h1><p>These destination and hero photographs are included locally in the project. Each file has its own author and reuse terms. Please retain its credit and follow the linked license when reusing the photo.</p><ul>",
    ]
    for name in names:
        c = selected[name]
        author = c["artist"] or c["credit"] or "Author as listed on Wikimedia Commons"
        license_html = f"<a href=\"{html.escape(c['license_url'], quote=True)}\" target=\"_blank\" rel=\"noopener noreferrer\">{html.escape(c['license'])}</a>" if c["license_url"] else html.escape(c["license"])
        credits_html.append(
            f"<li><strong>{html.escape(name)}</strong>Photo: {html.escape(author)}<div class=\"license\">License: {license_html}</div>"
            f"<a href=\"{html.escape(c['source_url'], quote=True)}\" target=\"_blank\" rel=\"noopener noreferrer\">View original file and full details on Wikimedia Commons</a></li>"
        )
    hero_license_html = f"<a href=\"{html.escape(HERO_CREDIT['license_url'], quote=True)}\" target=\"_blank\" rel=\"noopener noreferrer\">{html.escape(HERO_CREDIT['license'])}</a>"
    credits_html.append(
        f"<li><strong>Homepage hero — Bhimashankar Wildlife Sanctuary</strong>Photo: {html.escape(HERO_CREDIT['artist'])}. {html.escape(HERO_CREDIT['adaptation'])}"
        f"<div class=\"license\">License: {hero_license_html}</div>"
        f"<a href=\"{html.escape(HERO_CREDIT['source_url'], quote=True)}\" target=\"_blank\" rel=\"noopener noreferrer\">View original file and full details on Wikimedia Commons</a></li>"
    )
    credits_html.append("</ul></main></body></html>")
    (ROOT / "static/photo-credits.html").write_text("\n".join(credits_html) + "\n", encoding="utf-8")
    print(f"\nCollected {len(selected)} unique Commons photos. Credits saved to {OUT / 'CREDITS.md'}")


if __name__ == "__main__":
    main()
