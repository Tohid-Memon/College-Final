package com.maharashtra.tourism.service;

import com.maharashtra.tourism.dto.BudgetRequest;
import com.maharashtra.tourism.dto.BudgetResponse;
import com.maharashtra.tourism.entity.Attraction;
import com.maharashtra.tourism.entity.Destination;
import com.maharashtra.tourism.exception.NotFoundException;
import com.maharashtra.tourism.repository.AttractionRepository;
import com.maharashtra.tourism.repository.DestinationRepository;
import com.maharashtra.tourism.repository.HotelRepository;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class TourismService {
    private static final int DAY_START = 9 * 60;
    private static final int LUNCH_START = 12 * 60 + 30;
    private static final int LUNCH_END = 13 * 60 + 30;
    private static final int MAX_STOPS_PER_DAY = 3;

    private final DestinationRepository destinations;
    private final AttractionRepository attractions;
    private final HotelRepository hotels;

    public TourismService(DestinationRepository destinations, AttractionRepository attractions, HotelRepository hotels) {
        this.destinations = destinations;
        this.attractions = attractions;
        this.hotels = hotels;
    }

    public List<Destination> allDestinations() {
        return destinations.findAll(Sort.by("name").ascending());
    }

    public List<Destination> search(String query) {
        if (query == null || query.isBlank()) return allDestinations();
        return destinations.findByNameContainingIgnoreCaseOrderByNameAsc(query.trim());
    }

    public Destination destination(Long id) {
        return destinations.findById(id)
            .orElseThrow(() -> new NotFoundException("Destination not found. Try a popular Maharashtra destination."));
    }

    public Destination byName(String name) {
        return destinations.findByNameIgnoreCase(name.trim())
            .orElseThrow(() -> new NotFoundException("We don't have information about this destination yet. Please check the spelling or try another Maharashtra destination."));
    }

    public List<Attraction> attractions(Long id) {
        destination(id);
        return attractions.findByDestination_IdOrderByIdAsc(id);
    }

    public List<com.maharashtra.tourism.entity.Hotel> hotels(Long id) {
        destination(id);
        return hotels.findByDestination_IdOrderByPricePerNightAsc(id);
    }

    /**
     * Creates a time-feasible suggested plan: up to three distinct visits per day,
     * realistic visit lengths, estimated transfer buffers, a protected lunch break,
     * and explicit start/end times. It never repeats a stop to pad extra days.
     */
    public Map<String, Object> itinerary(Long id, int days) {
        if (days < 1 || days > 3) throw new IllegalArgumentException("Choose an itinerary of 1, 2, or 3 days.");
        Destination destination = destination(id);
        List<Attraction> available = attractions.findByDestination_IdOrderByIdAsc(id);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("destination", destination.getName());
        result.put("days", days);

        if (available.isEmpty()) {
            result.put("message", "There are no guide stops for this destination yet. Refresh or restart the app to load the destination guide.");
            result.put("plan", List.of());
            return result;
        }

        int maximumVisits = Math.min(available.size(), days * MAX_STOPS_PER_DAY);
        List<List<Attraction>> dailyStops = new ArrayList<>();
        for (int day = 0; day < days; day++) dailyStops.add(new ArrayList<>());
        int totalVisits = 0;
        for (Attraction candidate : available.subList(0, maximumVisits)) {
            List<Integer> dayOrder = new ArrayList<>();
            for (int day = 0; day < days; day++) dayOrder.add(day);
            dayOrder.sort((left, right) -> Integer.compare(dailyStops.get(left).size(), dailyStops.get(right).size()));
            for (int day : dayOrder) {
                List<Attraction> bucket = dailyStops.get(day);
                if (bucket.size() >= MAX_STOPS_PER_DAY || !fitsWithinDay(bucket, candidate)) continue;
                bucket.add(candidate);
                totalVisits++;
                break;
            }
        }
        List<Map<String, Object>> plan = new ArrayList<>();
        for (int dayNumber = 1; dayNumber <= days; dayNumber++) {
            List<Attraction> dayStops = dailyStops.get(dayNumber - 1);
            if (dayStops.isEmpty()) continue;
            plan.add(scheduleDay(dayNumber, dayStops));
        }
        result.put("plan", plan);
        result.put("scheduledVisits", totalVisits);
        result.put("availableVisits", available.size());
        result.put("note", "Times and transfers are planning estimates, not confirmed opening hours or live traffic. Days are kept within about 9:00 AM–6:00 PM; if a long visit would overfill a day, fewer stops are shown. Check current access, permits, weather, tide and operator guidance before travel. Stops are not repeated to pad days.");
        return result;
    }

    private boolean fitsWithinDay(List<Attraction> currentStops, Attraction candidate) {
        List<Attraction> stops = new ArrayList<>(currentStops);
        stops.add(candidate);
        int clock = DAY_START;
        boolean lunchAdded = false;
        for (int index = 0; index < stops.size(); index++) {
            Attraction stop = stops.get(index);
            int travel = index == 0 ? bounded(stop.getTravelMinutes(), 0, 90, 15)
                : bounded(stop.getTravelMinutes(), 10, 90, 25);
            int visit = bounded(stop.getVisitMinutes(), 30, 240, 60);
            if (!lunchAdded && clock >= LUNCH_START) {
                clock += 60;
                lunchAdded = true;
            } else if (!lunchAdded && clock < LUNCH_START && clock + travel >= LUNCH_START) {
                clock = LUNCH_END;
                lunchAdded = true;
            }
            clock += travel + visit;
            if (!lunchAdded && clock >= LUNCH_START) {
                clock += 60;
                lunchAdded = true;
            }
        }
        return clock <= 18 * 60;
    }

    private Map<String, Object> scheduleDay(int dayNumber, List<Attraction> stops) {
        List<Map<String, Object>> activities = new ArrayList<>();
        int clock = DAY_START;
        boolean lunchAdded = false;

        for (int index = 0; index < stops.size(); index++) {
            Attraction stop = stops.get(index);
            int travel = index == 0 ? bounded(stop.getTravelMinutes(), 0, 90, 15)
                : bounded(stop.getTravelMinutes(), 10, 90, 25);
            int visit = bounded(stop.getVisitMinutes(), 30, 240, 60);

            // Let a long late-morning visit finish first; place lunch after it.
            if (!lunchAdded && clock >= LUNCH_START) {
                int breakStart = Math.max(clock, LUNCH_START);
                activities.add(breakActivity("Lunch and rest", breakStart, 60,
                    "A protected meal and hydration break; adjust to local meal times."));
                clock = breakStart + 60;
                lunchAdded = true;
            } else if (!lunchAdded && clock < LUNCH_START && clock + travel >= LUNCH_START) {
                activities.add(breakActivity("Lunch and rest", LUNCH_START, 60,
                    "A protected meal and hydration break; adjust to local meal times."));
                clock = LUNCH_END;
                lunchAdded = true;
            }

            clock += travel;
            Map<String, Object> activity = new LinkedHashMap<>();
            activity.put("period", timeRange(clock, clock + visit));
            activity.put("startTime", clockText(clock));
            activity.put("endTime", clockText(clock + visit));
            activity.put("attraction", stop.getName());
            activity.put("description", stop.getDescription() == null
                ? "Allow time to explore at a comfortable pace."
                : stop.getDescription());
            activity.put("category", stop.getCategory() == null ? "Visit" : stop.getCategory());
            activity.put("durationMinutes", visit);
            activity.put("travelMinutes", travel);
            activity.put("visitPeriod", stop.getVisitPeriod() == null ? "Flexible" : stop.getVisitPeriod());
            activity.put("entryFee", stop.getEntryFee());
            activities.add(activity);
            clock += visit;
            if (!lunchAdded && clock >= LUNCH_START) {
                activities.add(breakActivity("Lunch and rest", clock, 60,
                    "A protected meal and hydration break; adjust to local meal times."));
                clock += 60;
                lunchAdded = true;
            }
        }

        Map<String, Object> day = new LinkedHashMap<>();
        day.put("day", dayNumber);
        day.put("startTime", clockText(DAY_START));
        day.put("endTime", clockText(clock));
        day.put("durationMinutes", clock - DAY_START);
        day.put("visitCount", stops.size());
        day.put("activities", activities);
        return day;
    }

    private Map<String, Object> breakActivity(String title, int start, int duration, String description) {
        Map<String, Object> activity = new LinkedHashMap<>();
        activity.put("period", timeRange(start, start + duration));
        activity.put("startTime", clockText(start));
        activity.put("endTime", clockText(start + duration));
        activity.put("attraction", title);
        activity.put("description", description);
        activity.put("category", "Meal / rest break");
        activity.put("durationMinutes", duration);
        activity.put("travelMinutes", 0);
        activity.put("visitPeriod", "Scheduled break");
        activity.put("entryFee", null);
        return activity;
    }

    private int bounded(Integer value, int min, int max, int fallback) {
        if (value == null) return fallback;
        return Math.max(min, Math.min(max, value));
    }

    private String timeRange(int start, int end) {
        return clockText(start) + "–" + clockText(end);
    }

    private String clockText(int minutes) {
        int normalized = minutes % (24 * 60);
        int hour = normalized / 60;
        int minute = normalized % 60;
        int shownHour = hour % 12 == 0 ? 12 : hour % 12;
        return String.format(Locale.ROOT, "%d:%02d %s", shownHour, minute, hour < 12 ? "AM" : "PM");
    }

    public BudgetResponse calculate(BudgetRequest request) {
        String category = request.hotelCategory().toLowerCase(Locale.ROOT);
        if (!Set.of("budget", "standard", "premium").contains(category)) {
            throw new IllegalArgumentException("Hotel category must be budget, standard, or premium.");
        }
        int nights = Math.max(0, request.days() - 1);
        BigDecimal rate = switch (category) {
            case "budget" -> new BigDecimal("1200");
            case "standard" -> new BigDecimal("2500");
            default -> new BigDecimal("5000");
        };
        BigDecimal accommodation = rate.multiply(BigDecimal.valueOf(request.rooms())).multiply(BigDecimal.valueOf(nights));
        BigDecimal food = request.dailyFoodPerPerson().multiply(BigDecimal.valueOf(request.travellers()))
            .multiply(BigDecimal.valueOf(request.days()));
        BigDecimal total = accommodation.add(food).add(request.transportation()).add(request.miscellaneous());
        return new BudgetResponse(
            money(accommodation), money(food), money(request.transportation()), money(request.miscellaneous()),
            money(total), money(total.divide(BigDecimal.valueOf(request.travellers()), 2, RoundingMode.HALF_UP)),
            nights,
            "Demo estimate. Hotel rates are illustrative category averages, rooms default to one per two travellers, and one-day trips have zero hotel nights."
        );
    }

    private BigDecimal money(BigDecimal number) {
        return number.setScale(2, RoundingMode.HALF_UP);
    }
}
