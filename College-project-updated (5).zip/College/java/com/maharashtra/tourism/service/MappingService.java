package com.maharashtra.tourism.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maharashtra.tourism.dto.MapDtos.GeocodedPlace;
import com.maharashtra.tourism.dto.MapDtos.NearbyPlace;
import com.maharashtra.tourism.dto.MapDtos.RoutePlan;
import com.maharashtra.tourism.dto.MapDtos.RoutePoint;
import com.maharashtra.tourism.dto.MapDtos.RouteRequest;
import com.maharashtra.tourism.dto.MapDtos.RouteStop;
import com.maharashtra.tourism.entity.Attraction;
import com.maharashtra.tourism.entity.Destination;
import com.maharashtra.tourism.repository.AttractionRepository;
import com.maharashtra.tourism.repository.DestinationRepository;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

@Service
public class MappingService {
    private static final Logger log = LoggerFactory.getLogger(MappingService.class);
    private static final String APP_USER_AGENT = "MaharashtraTrails/2.0 (tourism-planner; user-triggered nearby search)";
    private static final Duration GEOCODE_TTL = Duration.ofDays(30);
    private static final Duration NEARBY_TTL = Duration.ofHours(6);
    private static final int MAX_ROUTE_STOPS = 8;
    private static final int MAX_NEARBY_RESULTS = 40;

    private final RestClient http;
    private final RestClient overpassHttp;
    private final ObjectMapper objectMapper;
    private final AttractionRepository attractions;
    private final DestinationRepository destinations;
    private final ConcurrentMap<String, CacheValue<GeocodedPlace>> geocodeCache = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, CacheValue<List<NearbyPlace>>> nearbyCache = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Object> tileLocks = new ConcurrentHashMap<>();

    @Value("${tourism.map.nominatim-url:https://nominatim.openstreetmap.org}")
    private String nominatimBaseUrl;

    @Value("${tourism.map.overpass-url:https://overpass-api.de/api/interpreter}")
    private String overpassUrl;

    @Value("${tourism.map.overpass-fallback-urls:https://overpass-api.de/api/interpreter,https://gall.openstreetmap.de/api/interpreter,https://overpass.kumi.systems/api/interpreter}")
    private String overpassFallbackUrls;

    @Value("${tourism.map.osrm-url:https://router.project-osrm.org}")
    private String osrmBaseUrl;

    @Value("${tourism.map.tile-url:https://tile.openstreetmap.org}")
    private String tileBaseUrl;

    @Value("${tourism.map.tile-cache-path:./data/osm-tiles}")
    private String tileCachePath;

    private long lastNominatimRequestMillis;
    private long lastOverpassRequestMillis;
    private long lastOsrmRequestMillis;

    public MappingService(ObjectMapper objectMapper, AttractionRepository attractions, DestinationRepository destinations) {
        this.objectMapper = objectMapper;
        this.attractions = attractions;
        this.destinations = destinations;
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(Duration.ofSeconds(5));
        factory.setReadTimeout(Duration.ofSeconds(22));
        this.http = RestClient.builder().requestFactory(factory).build();

        SimpleClientHttpRequestFactory overpassFactory = new SimpleClientHttpRequestFactory();
        overpassFactory.setConnectTimeout(Duration.ofSeconds(4));
        overpassFactory.setReadTimeout(Duration.ofSeconds(9));
        this.overpassHttp = RestClient.builder().requestFactory(overpassFactory).build();
    }

    public GeocodedPlace geocode(String query) {
        if (query == null || query.isBlank() || query.trim().length() > 180) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Enter a place name of up to 180 characters.");
        }
        String normalized = query.trim().replaceAll("\\s+", " ");
        if (!normalized.toLowerCase(Locale.ROOT).contains("maharashtra")) normalized += ", Maharashtra, India";
        String cacheKey = normalized.toLowerCase(Locale.ROOT);
        GeocodedPlace cached = cacheGet(geocodeCache, cacheKey);
        if (cached != null) return cached;

        URI uri = UriComponentsBuilder.fromUriString(trimSlash(nominatimBaseUrl) + "/search")
            .queryParam("q", normalized)
            .queryParam("format", "jsonv2")
            .queryParam("limit", "1")
            .queryParam("countrycodes", "in")
            .build().encode().toUri();
        JsonNode response = nominatimGet(uri);
        if (!response.isArray() || response.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "We could not find that place in Maharashtra. Try a nearby town or destination name.");
        }
        JsonNode match = response.get(0);
        double latitude = number(match.path("lat"));
        double longitude = number(match.path("lon"));
        validateMaharashtra(latitude, longitude);
        GeocodedPlace place = new GeocodedPlace(match.path("display_name").asText(normalized), latitude, longitude);
        cachePut(geocodeCache, cacheKey, place, GEOCODE_TTL, 500);
        return place;
    }

    public List<NearbyPlace> nearby(double latitude, double longitude, int radiusKm, String placeName) {
        validateMaharashtra(latitude, longitude);
        if (radiusKm < 3 || radiusKm > 10) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Choose a search radius between 3 and 10 kilometres.");
        }
        String cacheKey = String.format(Locale.ROOT, "%.4f:%.4f:%d", latitude, longitude, radiusKm);
        List<NearbyPlace> cached = cacheGet(nearbyCache, cacheKey);
        if (cached != null) return cached;

        int radiusMeters = radiusKm * 1000;
        String lat = String.format(Locale.ROOT, "%.6f", latitude);
        String lon = String.format(Locale.ROOT, "%.6f", longitude);
        String around = "(around:" + radiusMeters + "," + lat + "," + lon + ")";
        String query = "[out:json][timeout:10];(" +
            "nwr" + around + "[\"name\"][\"tourism\"~\"attraction|museum|viewpoint\"];" +
            "nwr" + around + "[\"name\"][\"historic\"~\"castle|fort|monument|ruins\"];" +
            ");out center 60;";
        JsonNode response;
        try {
            response = overpassGet(query);
        } catch (ResponseStatusException exception) {
            List<NearbyPlace> localResults = nearbyFallback(latitude, longitude, radiusKm, placeName);
            if (!localResults.isEmpty()) {
                cachePut(nearbyCache, cacheKey, localResults, NEARBY_TTL, 300);
                log.warn("Overpass was unavailable; returned {} in-radius OpenStreetMap places from fallback search for {}", localResults.size(), placeName);
                return localResults;
            }
            throw exception;
        }
        JsonNode elements = response.path("elements");
        if (!elements.isArray()) throw upstreamError("Nearby attraction data is temporarily unavailable. Please try again shortly.");

        List<NearbyPlace> places = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (JsonNode element : elements) {
            JsonNode tags = element.path("tags");
            String name = tags.path("name").asText("").trim();
            if (name.isEmpty()) continue;
            double placeLat = element.has("lat") ? element.path("lat").asDouble(Double.NaN) : element.path("center").path("lat").asDouble(Double.NaN);
            double placeLon = element.has("lon") ? element.path("lon").asDouble(Double.NaN) : element.path("center").path("lon").asDouble(Double.NaN);
            if (!Double.isFinite(placeLat) || !Double.isFinite(placeLon) || !inMaharashtra(placeLat, placeLon)) continue;
            double distance = haversineKm(latitude, longitude, placeLat, placeLon);
            if (distance > radiusKm) continue;
            String type = element.path("type").asText("node");
            String osmId = element.path("id").asText("");
            String key = name.toLowerCase(Locale.ROOT) + "|" + Math.round(placeLat * 1000) + "|" + Math.round(placeLon * 1000);
            if (!seen.add(key)) continue;
            String osmUrl = "https://www.openstreetmap.org/" + type + "/" + osmId;
            places.add(new NearbyPlace(type + "/" + osmId, name, category(tags), placeLat, placeLon,
                Math.round(distance * 100.0) / 100.0, osmUrl));
        }
        places.sort(Comparator.comparingDouble(NearbyPlace::distanceKm).thenComparing(NearbyPlace::name, String.CASE_INSENSITIVE_ORDER));
        List<NearbyPlace> result = List.copyOf(places.stream().limit(MAX_NEARBY_RESULTS).toList());
        if (result.isEmpty()) {
            List<NearbyPlace> localResults = nearbyFallback(latitude, longitude, radiusKm, placeName);
            if (!localResults.isEmpty()) result = localResults;
        }
        cachePut(nearbyCache, cacheKey, result, NEARBY_TTL, 300);
        return result;
    }

    private List<NearbyPlace> nearbyFallback(double latitude, double longitude, int radiusKm, String placeName) {
        List<NearbyPlace> searchResults = nominatimNearby(latitude, longitude, radiusKm);
        return searchResults.isEmpty() ? curatedNearby(latitude, longitude, radiusKm, placeName) : searchResults;
    }

    private List<NearbyPlace> nominatimNearby(double latitude, double longitude, int radiusKm) {
        double latDelta = radiusKm / 110.574;
        double longitudeScale = Math.max(0.2, Math.cos(Math.toRadians(latitude)));
        double lonDelta = radiusKm / (111.320 * longitudeScale);
        String viewbox = String.format(Locale.ROOT, "%.6f,%.6f,%.6f,%.6f",
            longitude - lonDelta, latitude + latDelta, longitude + lonDelta, latitude - latDelta);
        List<NearbyPlace> results = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (String term : List.of("attraction", "museum", "temple", "park", "waterfall", "lake", "viewpoint", "dam", "beach")) {
            URI uri = UriComponentsBuilder.fromUriString(trimSlash(nominatimBaseUrl) + "/search")
                .queryParam("q", term)
                .queryParam("format", "jsonv2")
                .queryParam("limit", "40")
                .queryParam("countrycodes", "in")
                .queryParam("viewbox", viewbox)
                .queryParam("bounded", "1")
                .build().encode().toUri();
            JsonNode response;
            try {
                response = nominatimGet(uri);
            } catch (ResponseStatusException exception) {
                log.warn("Bounded nearby search for {} could not complete: {}", term, exception.getReason());
                if (exception.getStatusCode().value() >= 500) break;
                continue;
            }
            if (!response.isArray()) continue;
            for (JsonNode match : response) {
                double placeLat = match.path("lat").asDouble(Double.NaN);
                double placeLon = match.path("lon").asDouble(Double.NaN);
                if (!Double.isFinite(placeLat) || !Double.isFinite(placeLon)) continue;
                if (!inMaharashtra(placeLat, placeLon)) continue;
                double distance = haversineKm(latitude, longitude, placeLat, placeLon);
                if (distance > radiusKm) continue;
                String osmType = match.path("osm_type").asText("").toLowerCase(Locale.ROOT);
                String osmId = match.path("osm_id").asText("");
                if (!Set.of("node", "way", "relation").contains(osmType) || !osmId.matches("[0-9]{1,20}")) continue;
                String name = match.path("name").asText("").trim();
                if (name.isEmpty()) name = match.path("display_name").asText("Nearby place").split(",", 2)[0].trim();
                if (name.isEmpty()) continue;
                String key = osmType + "/" + osmId;
                if (!seen.add(key)) continue;
                String category = match.path("type").asText(term).replace('_', ' ');
                results.add(new NearbyPlace(key, name, category, placeLat, placeLon,
                    Math.round(distance * 100.0) / 100.0,
                    "https://www.openstreetmap.org/" + key));
            }
            if (results.size() >= 15) break;
        }
        results.sort(Comparator.comparingDouble(NearbyPlace::distanceKm).thenComparing(NearbyPlace::name, String.CASE_INSENSITIVE_ORDER));
        return List.copyOf(results.stream().limit(MAX_NEARBY_RESULTS).toList());
    }

    private List<NearbyPlace> curatedNearby(double latitude, double longitude, int radiusKm, String placeName) {
        if (placeName == null || placeName.isBlank()) return List.of();
        String destinationName = placeName.trim().split(",", 2)[0].trim();
        Destination destination = destinations.findByNameIgnoreCase(destinationName).orElse(null);
        if (destination == null) return List.of();

        List<NearbyPlace> results = new ArrayList<>();
        for (Attraction attraction : attractions.findByDestination_IdOrderByIdAsc(destination.getId())) {
            String name = attraction.getName();
            String normalized = name == null ? "" : name.toLowerCase(Locale.ROOT);
            if (normalized.contains("local walk and meal stop") || normalized.contains("visitor-area rest stop")) continue;
            String query = name + ", " + destination.getName() + ", " + destination.getDistrict() + ", Maharashtra, India";
            try {
                GeocodedPlace geocoded = geocode(query);
                double distance = haversineKm(latitude, longitude, geocoded.latitude(), geocoded.longitude());
                if (distance > radiusKm) continue;
                String id = "curated/" + attraction.getId();
                results.add(new NearbyPlace(id, name,
                    attraction.getCategory() == null || attraction.getCategory().isBlank() ? "Attraction" : attraction.getCategory(),
                    geocoded.latitude(), geocoded.longitude(), Math.round(distance * 100.0) / 100.0,
                    osmMapUrl(geocoded.latitude(), geocoded.longitude())));
            } catch (ResponseStatusException exception) {
                if (exception.getStatusCode().value() >= 500) {
                    log.warn("Place lookup stopped while locating guide attractions for {}: {}", destination.getName(), exception.getReason());
                    break;
                }
                log.debug("Guide attraction {} could not be matched to a mapped place", name);
            }
        }
        results.sort(Comparator.comparingDouble(NearbyPlace::distanceKm).thenComparing(NearbyPlace::name, String.CASE_INSENSITIVE_ORDER));
        return List.copyOf(results.stream().limit(MAX_NEARBY_RESULTS).toList());
    }

    public byte[] tile(int z, int x, int y, String referer) {
        if (z < 0 || z > 19 || x < 0 || y < 0 || x >= (1 << z) || y >= (1 << z)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "That map tile is outside the supported zoom range.");
        }
        Path path = Path.of(tileCachePath, Integer.toString(z), Integer.toString(x), y + ".png");
        Object lock = tileLocks.computeIfAbsent(path.toString(), ignored -> new Object());
        synchronized (lock) {
            try {
                if (Files.isRegularFile(path) && Files.size(path) > 0) return Files.readAllBytes(path);
                URI uri = URI.create(trimSlash(tileBaseUrl) + "/" + z + "/" + x + "/" + y + ".png");
                String pageReferer = referer != null && (referer.startsWith("https://") || referer.startsWith("http://"))
                    ? referer : "http://localhost/route-planner.html";
                byte[] image = http.get().uri(uri).header("User-Agent", APP_USER_AGENT)
                    .header("Referer", pageReferer).retrieve().body(byte[].class);
                if (image == null || image.length == 0) throw upstreamError("The map tile provider returned an empty image.");
                Files.createDirectories(path.getParent());
                Path temporary = Files.createTempFile(path.getParent(), "tile-", ".tmp");
                Files.write(temporary, image);
                try {
                    Files.move(temporary, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                    Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING);
                }
                return image;
            } catch (RestClientResponseException | ResourceAccessException exception) {
                throw upstreamError("The map tiles are temporarily unavailable. The route list can still be used.");
            } catch (java.io.IOException exception) {
                throw upstreamError("The map tile cache could not be read or written.");
            }
        }
    }

    public RoutePlan route(RouteRequest request) {
        if (request == null || request.origin() == null || request.stops() == null || request.stops().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Choose a starting point and at least one nearby place.");
        }
        if (request.stops().size() > MAX_ROUTE_STOPS) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Select no more than " + MAX_ROUTE_STOPS + " stops for one route.");
        }
        RoutePoint origin = request.origin();
        validateMaharashtra(origin.latitude(), origin.longitude());
        validateName(origin.name());
        List<NearbyPlace> selected = List.copyOf(request.stops());
        Set<String> ids = new HashSet<>();
        for (NearbyPlace stop : selected) {
            if (stop == null || stop.id() == null || !stop.id().matches("(node|way|relation|curated)/[0-9]{1,20}")) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "One of the selected place identifiers is invalid. Search again and reselect your stops.");
            }
            if (!ids.add(stop.id())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A route cannot include the same place twice.");
            validateMaharashtra(stop.latitude(), stop.longitude());
            validateName(stop.name());
        }

        List<RoutePoint> points = new ArrayList<>();
        points.add(origin);
        for (NearbyPlace stop : selected) points.add(new RoutePoint(stop.name(), stop.latitude(), stop.longitude()));
        String coordinates = coordinatePath(points);
        try {
        JsonNode table = osrmGet(trimSlash(osrmBaseUrl) + "/table/v1/driving/" + coordinates + "?annotations=duration,distance");
        if (!"Ok".equals(table.path("code").asText())) {
            throw upstreamError("The road-routing service could not connect these places. Try fewer stops or a smaller search radius.");
        }
        JsonNode durations = table.path("durations");
        if (!durations.isArray() || durations.size() != points.size()) {
            throw upstreamError("The road-routing service returned an incomplete route matrix. Please try again.");
        }
        if (!hasUsableRoadLeg(table.path("distances"), points.size())) {
            return walkingEstimate(points, selected);
        }

        List<Integer> order = nearestRoadTimeOrder(durations, points.size());
        List<RoutePoint> orderedPoints = order.stream().map(points::get).toList();
        String orderedCoordinates = coordinatePath(orderedPoints);
        JsonNode route = osrmGet(trimSlash(osrmBaseUrl) + "/route/v1/driving/" + orderedCoordinates + "?overview=full&geometries=geojson&steps=false");
        if (!"Ok".equals(route.path("code").asText()) || route.path("routes").isEmpty()) {
            throw upstreamError("The routing service could not draw a road between every selected place. Remove a stop and try again.");
        }
        JsonNode bestRoute = route.path("routes").get(0);
        if (bestRoute.path("distance").asDouble(0) < 1 && hasDistinctLocations(points)) {
            return walkingEstimate(points, selected);
        }
        List<RouteStop> stops = new ArrayList<>();
        for (int position = 0; position < order.size(); position++) {
            int originalIndex = order.get(position);
            RoutePoint point = points.get(originalIndex);
            double legDistance = 0;
            double legDuration = 0;
            String category = "Starting point";
            String mapUrl = osmMapUrl(point.latitude(), point.longitude());
            if (originalIndex > 0) {
                NearbyPlace source = selected.get(originalIndex - 1);
                category = source.category();
                mapUrl = source.mapUrl();
                JsonNode leg = bestRoute.path("legs").path(position - 1);
                legDistance = leg.path("distance").asDouble(0);
                legDuration = leg.path("duration").asDouble(0);
            }
            stops.add(new RouteStop(position, point.name(), category, point.latitude(), point.longitude(),
                legDistance, legDuration, mapUrl));
        }
        Map<String, Object> geometry = objectMapper.convertValue(bestRoute.path("geometry"), objectMapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class));
        return new RoutePlan(List.copyOf(stops), geometry, bestRoute.path("distance").asDouble(0),
            bestRoute.path("duration").asDouble(0),
            "driving",
            "The suggested order chooses the closest remaining stop by estimated road travel time. Distances and times are estimates, not live traffic or confirmed opening hours.");
        } catch (ResponseStatusException exception) {
            if (exception.getStatusCode().value() < 500) throw exception;
            log.warn("Road routing is unavailable; returning a labelled straight-line estimate: {}", exception.getReason());
            return walkingEstimate(points, selected,
                "The road-routing service is temporarily unavailable. Stop order uses straight-line distance and the duration is estimated at 3 km/h; this is not a mapped walking or driving path. Check local roads and access before setting out.");
        }
    }

    private RoutePlan walkingEstimate(List<RoutePoint> points, List<NearbyPlace> selected) {
        return walkingEstimate(points, selected,
            "No usable drivable-road route was returned for these stops. The line is straight-line distance and time estimated at 3 km/h; it is not a mapped walking path. Check local paths and access before setting out.");
    }

    private RoutePlan walkingEstimate(List<RoutePoint> points, List<NearbyPlace> selected, String note) {
        List<Integer> order = nearestStraightLineOrder(points);
        List<RouteStop> stops = new ArrayList<>();
        double totalDistance = 0;
        double totalDuration = 0;
        List<List<Double>> coordinates = new ArrayList<>();
        RoutePoint previous = null;
        for (int position = 0; position < order.size(); position++) {
            int originalIndex = order.get(position);
            RoutePoint point = points.get(originalIndex);
            coordinates.add(List.of(point.longitude(), point.latitude()));
            double legDistance = 0;
            double legDuration = 0;
            String category = "Starting point";
            String mapUrl = osmMapUrl(point.latitude(), point.longitude());
            if (previous != null) {
                legDistance = haversineKm(previous.latitude(), previous.longitude(), point.latitude(), point.longitude()) * 1000;
                legDuration = legDistance / (3000.0 / 3600.0);
                totalDistance += legDistance;
                totalDuration += legDuration;
                NearbyPlace source = selected.get(originalIndex - 1);
                category = source.category();
                mapUrl = source.mapUrl();
            }
            stops.add(new RouteStop(position, point.name(), category, point.latitude(), point.longitude(),
                legDistance, legDuration, mapUrl));
            previous = point;
        }
        Map<String, Object> geometry = Map.of("type", "LineString", "coordinates", coordinates);
        return new RoutePlan(List.copyOf(stops), geometry, totalDistance, totalDuration, "walking-estimate", note);
    }

    private List<Integer> nearestStraightLineOrder(List<RoutePoint> points) {
        List<Integer> order = new ArrayList<>();
        Set<Integer> visited = new HashSet<>();
        int current = 0;
        order.add(current);
        visited.add(current);
        while (order.size() < points.size()) {
            int nearest = -1;
            double nearestKm = Double.POSITIVE_INFINITY;
            RoutePoint from = points.get(current);
            for (int candidate = 1; candidate < points.size(); candidate++) {
                if (visited.contains(candidate)) continue;
                RoutePoint to = points.get(candidate);
                double distance = haversineKm(from.latitude(), from.longitude(), to.latitude(), to.longitude());
                if (distance < nearestKm) { nearestKm = distance; nearest = candidate; }
            }
            if (nearest < 0) break;
            order.add(nearest);
            visited.add(nearest);
            current = nearest;
        }
        return order;
    }

    private boolean hasUsableRoadLeg(JsonNode distances, int count) {
        if (!distances.isArray() || distances.size() != count) return false;
        for (int from = 0; from < count; from++) {
            JsonNode row = distances.path(from);
            for (int to = 0; to < count; to++) {
                if (from != to && row.path(to).isNumber() && row.path(to).asDouble() > 1) return true;
            }
        }
        return false;
    }

    private boolean hasDistinctLocations(List<RoutePoint> points) {
        for (int left = 0; left < points.size(); left++) {
            for (int right = left + 1; right < points.size(); right++) {
                RoutePoint a = points.get(left), b = points.get(right);
                if (haversineKm(a.latitude(), a.longitude(), b.latitude(), b.longitude()) > 0.05) return true;
            }
        }
        return false;
    }

    private List<Integer> nearestRoadTimeOrder(JsonNode durations, int count) {
        List<Integer> order = new ArrayList<>();
        Set<Integer> visited = new HashSet<>();
        int current = 0;
        order.add(current);
        visited.add(current);
        while (order.size() < count) {
            JsonNode row = durations.path(current);
            int nearest = -1;
            double nearestSeconds = Double.POSITIVE_INFINITY;
            for (int candidate = 1; candidate < count; candidate++) {
                if (visited.contains(candidate)) continue;
                JsonNode value = row.path(candidate);
                if (value.isNumber() && value.asDouble() < nearestSeconds) {
                    nearestSeconds = value.asDouble();
                    nearest = candidate;
                }
            }
            if (nearest < 0 || !Double.isFinite(nearestSeconds)) {
                throw upstreamError("One of the selected places is not reachable by the road-routing service. Remove it and try again.");
            }
            order.add(nearest);
            visited.add(nearest);
            current = nearest;
        }
        return order;
    }

    private String coordinatePath(List<RoutePoint> points) {
        return points.stream().map(point -> String.format(Locale.ROOT, "%.6f,%.6f", point.longitude(), point.latitude()))
            .collect(Collectors.joining(";"));
    }

    private synchronized JsonNode nominatimGet(URI uri) {
        pace(1000, lastNominatimRequestMillis, value -> lastNominatimRequestMillis = value);
        try {
            return http.get().uri(uri).header("User-Agent", APP_USER_AGENT).retrieve().body(JsonNode.class);
        } catch (RestClientResponseException | ResourceAccessException exception) {
            throw upstreamError("The place-search service is temporarily unavailable. Please try again shortly.");
        }
    }

    private synchronized JsonNode overpassGet(String query) {
        List<String> endpoints = new ArrayList<>();
        endpoints.add(overpassUrl);
        if (overpassFallbackUrls != null) {
            for (String endpoint : overpassFallbackUrls.split(",")) endpoints.add(endpoint.trim());
        }
        List<String> tried = new ArrayList<>();
        for (String configuredEndpoint : endpoints) {
            String endpoint = trimSlash(configuredEndpoint);
            if (endpoint.isBlank() || tried.contains(endpoint)) continue;
            tried.add(endpoint);
            pace(1200, lastOverpassRequestMillis, value -> lastOverpassRequestMillis = value);
            URI uri = UriComponentsBuilder.fromUriString(endpoint)
                .queryParam("data", query).build().encode().toUri();
            try {
                JsonNode response = overpassHttp.get().uri(uri)
                    .header("User-Agent", APP_USER_AGENT)
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve().body(JsonNode.class);
                if (response != null && response.path("elements").isArray()) return response;
                log.warn("Overpass endpoint {} returned an invalid nearby-search response; trying another host", endpoint);
            } catch (RestClientResponseException exception) {
                log.warn("Overpass endpoint {} returned HTTP {}; trying another host", endpoint, exception.getStatusCode().value());
            } catch (RestClientException exception) {
                log.warn("Overpass endpoint {} could not complete a bounded nearby search: {}; trying another host", endpoint, exception.getMessage());
            }
        }
        throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
            "Nearby map data is temporarily unavailable from the public sources. Your starting point is saved; try again in a minute or choose another radius.");
    }

    private synchronized JsonNode osrmGet(String pathAndQuery) {
        pace(1100, lastOsrmRequestMillis, value -> lastOsrmRequestMillis = value);
        try {
            return http.get().uri(URI.create(pathAndQuery)).header("User-Agent", APP_USER_AGENT).retrieve().body(JsonNode.class);
        } catch (RestClientResponseException | ResourceAccessException exception) {
            throw upstreamError("The road-routing service is temporarily unavailable. Please try again shortly.");
        }
    }

    private void pace(long minimumMillis, long lastRequest, java.util.function.LongConsumer updateLastRequest) {
        long wait = minimumMillis - (System.currentTimeMillis() - lastRequest);
        if (lastRequest > 0 && wait > 0) {
            try {
                Thread.sleep(wait);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                throw upstreamError("The map request was interrupted. Please try again.");
            }
        }
        updateLastRequest.accept(System.currentTimeMillis());
    }

    private static <T> T cacheGet(ConcurrentMap<String, CacheValue<T>> cache, String key) {
        CacheValue<T> value = cache.get(key);
        if (value == null) return null;
        if (value.expiresAt().isBefore(Instant.now())) {
            cache.remove(key, value);
            return null;
        }
        return value.value();
    }

    private static <T> void cachePut(ConcurrentMap<String, CacheValue<T>> cache, String key, T value, Duration ttl, int maxEntries) {
        if (cache.size() >= maxEntries) cache.keySet().stream().findAny().ifPresent(cache::remove);
        cache.put(key, new CacheValue<>(Instant.now().plus(ttl), value));
    }

    private static String category(JsonNode tags) {
        for (String key : List.of("tourism", "historic", "natural", "leisure", "amenity")) {
            String value = tags.path(key).asText("");
            if (!value.isBlank()) return value.replace('_', ' ');
        }
        return "Attraction";
    }

    private static double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        double earthRadius = 6371.0088;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
            + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
            * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return earthRadius * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    private static void validateMaharashtra(double latitude, double longitude) {
        if (!Double.isFinite(latitude) || !Double.isFinite(longitude) || !inMaharashtra(latitude, longitude)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Choose a starting point within Maharashtra.");
        }
    }

    private static boolean inMaharashtra(double latitude, double longitude) {
        return latitude >= 15.0 && latitude <= 22.8 && longitude >= 72.0 && longitude <= 81.2;
    }

    private static void validateName(String name) {
        if (name == null || name.isBlank() || name.length() > 120) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A selected place has an invalid name. Search again and reselect your stops.");
        }
    }

    private static String osmMapUrl(double latitude, double longitude) {
        return String.format(Locale.ROOT, "https://www.openstreetmap.org/?mlat=%.6f&mlon=%.6f#map=15/%.6f/%.6f", latitude, longitude, latitude, longitude);
    }

    private static String trimSlash(String value) {
        return value == null ? "" : value.replaceAll("/+$", "");
    }

    private static double number(JsonNode value) {
        try { return Double.parseDouble(value.asText()); }
        catch (NumberFormatException exception) { throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "The place-search service returned an invalid location."); }
    }

    private static ResponseStatusException upstreamError(String message) {
        return new ResponseStatusException(HttpStatus.BAD_GATEWAY, message);
    }

    private record CacheValue<T>(Instant expiresAt, T value) {}
}
