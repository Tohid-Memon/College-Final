package com.maharashtra.tourism.dto;

public record AuthUserResponse(Long id, String name, String email) {}
