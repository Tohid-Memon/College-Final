package com.maharashtra.tourism.dto;

import java.util.List;
import java.util.Map;

public final class MapDtos {
    private MapDtos() {}

    public record GeocodedPlace(String displayName, double latitude, double longitude) {}

    public record NearbyPlace(
        String id,
        String name,
        String category,
        double latitude,
        double longitude,
        double distanceKm,
        String mapUrl
    ) {}

    public record RoutePoint(String name, double latitude, double longitude) {}

    public record RouteRequest(RoutePoint origin, List<NearbyPlace> stops) {}

    public record RouteStop(
        int order,
        String name,
        String category,
        double latitude,
        double longitude,
        double legDistanceMeters,
        double legDurationSeconds,
        String mapUrl
    ) {}

    public record RoutePlan(
        List<RouteStop> stops,
        Map<String, Object> geometry,
        double totalDistanceMeters,
        double totalDurationSeconds,
        String mode,
        String note
    ) {}
}
