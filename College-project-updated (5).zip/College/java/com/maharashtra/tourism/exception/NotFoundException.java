package com.maharashtra.tourism.exception;
public class NotFoundException extends RuntimeException { public NotFoundException(String message){super(message);} }
