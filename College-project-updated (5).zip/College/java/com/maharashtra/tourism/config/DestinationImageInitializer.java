package com.maharashtra.tourism.config;

import com.maharashtra.tourism.entity.Destination;
import com.maharashtra.tourism.repository.DestinationRepository;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;

@Configuration
public class DestinationImageInitializer {
    @Bean
    @Order(Ordered.LOWEST_PRECEDENCE)
    CommandLineRunner attachDestinationPhotos(DestinationRepository destinations) {
        return args -> {
            List<Destination> changed = new ArrayList<>();
            for (Destination destination : destinations.findAll()) {
                String fileName = slugify(destination.getName()) + ".jpg";
                String resourcePath = "static/images/destinations/" + fileName;
                if (!new ClassPathResource(resourcePath).exists()) {
                    continue;
                }
                String imageUrl = "/images/destinations/" + fileName;
                if (!imageUrl.equals(destination.getImageUrl())) {
                    destination.setImageUrl(imageUrl);
                    changed.add(destination);
                }
            }
            if (!changed.isEmpty()) {
                destinations.saveAll(changed);
                System.out.printf("Attached local photos to %d destinations.%n", changed.size());
            }
        };
    }

    private String slugify(String value) {
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replaceAll("\\p{M}", "")
            .toLowerCase(Locale.ROOT);
        return normalized.replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
    }
}
