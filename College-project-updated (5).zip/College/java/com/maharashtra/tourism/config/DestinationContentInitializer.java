package com.maharashtra.tourism.config;

import com.maharashtra.tourism.entity.Attraction;
import com.maharashtra.tourism.entity.Destination;
import com.maharashtra.tourism.entity.Hotel;
import com.maharashtra.tourism.repository.AttractionRepository;
import com.maharashtra.tourism.repository.DestinationRepository;
import com.maharashtra.tourism.repository.HotelRepository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

/** Incrementally fills destination guide content without resetting an existing user's database. */
@Configuration
public class DestinationContentInitializer {
    private static final int MIN_ATTRACTIONS_PER_DESTINATION = 6;

    @Bean
    @Order(2)
    CommandLineRunner enrichDestinationContent(
        DestinationRepository destinations,
        AttractionRepository attractions,
        HotelRepository hotels
    ) {
        return args -> {
            Map<String, Destination> byName = new HashMap<>();
            for (Destination destination : destinations.findAll()) {
                byName.put(destination.getName(), destination);
            }

            int attractionCount = 0;
            int hotelCount = 0;
            for (Map.Entry<String, List<Place>> entry : attractionCatalog().entrySet()) {
                Destination destination = byName.get(entry.getKey());
                if (destination == null) continue;

                List<Attraction> existing = attractions.findByDestination_IdOrderByIdAsc(destination.getId());
                Set<String> names = new HashSet<>();
                for (Attraction attraction : existing) names.add(normalize(attraction.getName()));
                int total = existing.size();
                for (Place place : entry.getValue()) {
                    if (total >= MIN_ATTRACTIONS_PER_DESTINATION) break;
                    if (!names.add(normalize(place.name()))) continue;
                    attractions.save(new Attraction(
                        destination,
                        place.name(),
                        place.description(),
                        place.category(),
                        place.period(),
                        place.visitMinutes(),
                        place.entryFee(),
                        place.travelMinutes()
                    ));
                    total++;
                    attractionCount++;
                }
                while (total < MIN_ATTRACTIONS_PER_DESTINATION) {
                    String baseName = destination.getName() + (total % 2 == 0
                        ? " local walk and meal stop" : " visitor-area rest stop");
                    String localStop = baseName;
                    int suffix = 2;
                    while (!names.add(normalize(localStop))) localStop = baseName + " " + suffix++;
                    attractions.save(new Attraction(
                        destination,
                        localStop,
                        "Flexible low-intensity stop near the destination centre; choose a currently open public food place or rest point locally.",
                        "Local walk / Rest stop",
                        "Flexible; check local availability",
                        60,
                        null,
                        15
                    ));
                    total++;
                    attractionCount++;
                }

                List<Hotel> existingHotels = hotels.findByDestination_IdOrderByPricePerNightAsc(destination.getId());
                Set<String> categories = new HashSet<>();
                for (Hotel hotel : existingHotels) categories.add(normalize(hotel.getCategory()));
                String locality = stayLocality(destination);
                if (!categories.contains("budget")) {
                    hotels.save(stay(destination, "Budget guesthouse idea near " + locality, "budget", 950,
                        "Illustrative low-cost stay option for trip planning; this is not a verified property or live listing.",
                        "Basic room; ask about meals, hot water and parking."));
                    hotelCount++;
                }
                if (!categories.contains("standard")) {
                    hotels.save(stay(destination, "Standard hotel idea in " + locality, "standard", 2100,
                        "Illustrative mid-range stay option for trip planning; confirm current local availability and rates.",
                        "Private room; confirm Wi-Fi, breakfast and check-in directly."));
                    hotelCount++;
                }
                if (!categories.contains("premium")) {
                    hotels.save(stay(destination, "Comfort stay idea near " + locality, "premium", 4200,
                        "Illustrative higher-comfort stay option for trip planning; not a real hotel booking or quote.",
                        "Comfort-focused stay; verify facilities, location and current price."));
                    hotelCount++;
                }
            }
            System.out.printf("Destination guide backfill added %d attraction details and %d illustrative stay ideas.%n",
                attractionCount, hotelCount);
        };
    }

    private static Hotel stay(Destination destination, String name, String category, int nightlyRate,
                             String description, String facilities) {
        return new Hotel(destination, name, category, BigDecimal.valueOf(nightlyRate), description, facilities);
    }

    private static String stayLocality(Destination destination) {
        String district = destination.getDistrict();
        String name = destination.getName();
        if (name.contains("Tiger Reserve") || name.contains("National Park")) return name + " access area";
        if (name.contains("Caves")) return name + " visitor area";
        if (name.contains("Fort") || name.contains("Waterfall")) return name + " base village";
        if (name.contains("Beach") || name.contains("Coastal") || name.contains("Coast")) return name + " town";
        if (Set.of("Matheran", "Lonavala", "Khandala", "Mahabaleshwar", "Panchgani", "Igatpuri",
            "Bhandardara", "Amboli", "Chikhaldara", "Jawhar", "Kamshet", "Lavasa").contains(name)) {
            return name + " market / town centre";
        }
        return (district == null || district.isBlank() ? name : district) + " town centre";
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private record Place(String name, String description, String category, String period,
                         int visitMinutes, int travelMinutes, BigDecimal entryFee) {}

    private static Place p(String name, String description, String category, int visitMinutes, int travelMinutes) {
        return new Place(name, description, category, "Flexible; check local hours", visitMinutes, travelMinutes, null);
    }

    private static Map<String, List<Place>> attractionCatalog() {
        Map<String, List<Place>> data = new LinkedHashMap<>();
        add(data, "Mumbai",
            p("Elephanta Caves", "Rock-cut cave monuments on Elephanta Island; allow time for the ferry and island walk.", "Heritage / Day trip", 150, 75),
            p("Haji Ali Dargah", "Tide-dependent island shrine on the Worli coast; confirm the causeway is accessible.", "Heritage / Religious", 60, 35),
            p("Bandra Fort and Bandstand", "Seafront heritage stop and promenade on the Bandra coast.", "Heritage / Walk", 75, 35));
        add(data, "Pune",
            p("Raja Dinkar Kelkar Museum", "Museum of Indian decorative arts and everyday heritage objects.", "Museum", 100, 20),
            p("Pataleshwar Cave Temple", "Rock-cut cave temple and courtyard in central Pune.", "Heritage / Religious", 45, 20),
            p("Parvati Hill", "Hilltop temple complex and city viewpoint; the ascent is by steps.", "Viewpoint / Religious", 75, 35),
            p("Aga Khan Palace gardens", "Historic palace grounds and Gandhi memorial in the Yerawada area.", "Heritage", 90, 35));
        add(data, "Matheran",
            p("Matheran market and heritage railway", "Walk the central bazaar and view the historic narrow-gauge railway area.", "Town walk", 75, 15),
            p("Alexander Point", "Forest-fringed viewpoint overlooking the surrounding valley.", "Viewpoint", 60, 35),
            p("Porcupine Point (Sunset Point)", "Western-facing cliff viewpoint; sunset visibility depends on weather.", "Viewpoint", 60, 40),
            p("Paymaster Park", "Shaded central garden stop for a quiet break between walking trails.", "Park", 45, 15));
        add(data, "Lonavala",
            p("Bhaja Caves", "Buddhist rock-cut cave group reached by a stepped approach; footwear and weather matter.", "Heritage", 100, 30),
            p("Lohagad Fort", "Hill fort walk near Malavli; allow extra time for ascent and seasonal trail conditions.", "Fort / Trek", 180, 55),
            p("Tiger Point", "Popular valley lookout; crowding and visibility vary with weather.", "Viewpoint", 50, 25),
            p("Lonavala town and chikki market", "Short town-centre stop for local snacks and shopping.", "Market / Food", 60, 15));
        add(data, "Khandala",
            p("Duke's Nose (Nagphani)", "Ridge viewpoint and trek; attempt only with suitable weather and footwear.", "Trek / Viewpoint", 150, 35),
            p("Kune Falls viewpoint", "Seasonal waterfall area; access and flow vary during the year.", "Waterfall", 60, 25),
            p("Rajmachi Point", "Roadside valley lookout between Khandala and Lonavala.", "Viewpoint", 45, 20),
            p("Khandala Ghat viewpoint", "Scenic Western Ghats road lookout; stop only at safe designated areas.", "Viewpoint", 45, 20),
            p("Lonavala town snack stop", "Nearby town-centre break for food and local snacks.", "Food / Market", 60, 25));
        add(data, "Mahabaleshwar",
            p("Pratapgad Fort", "Historic hill fort outside town; allow a separate drive and walking time.", "Fort / Heritage", 150, 75),
            p("Lingmala Waterfall viewpoint", "Seasonal waterfall lookout; water flow and paths vary by season.", "Waterfall", 60, 30),
            p("Old Mahabaleshwar temples", "Historic temple cluster near the source area of the Krishna River.", "Heritage / Religious", 75, 30),
            p("Mahabaleshwar market", "Town-centre walk for local produce, snacks and crafts.", "Market / Food", 60, 20));
        add(data, "Panchgani",
            p("Table Land", "Broad laterite plateau with open valley views; use marked paths and horse-ride guidance.", "Plateau / Viewpoint", 90, 15),
            p("Parsi Point", "Popular lookout over the Krishna valley and Dhom Dam reservoir.", "Viewpoint", 45, 20),
            p("Sydney Point", "Hilltop viewpoint toward the Dhom Dam and surrounding valley.", "Viewpoint", 45, 20),
            p("Panchgani bazaar", "Compact market stop for local snacks and seasonal produce.", "Market / Food", 60, 15),
            p("Rajpuri Caves", "Cave and kund complex outside the central town; confirm local access before visiting.", "Heritage / Religious", 75, 35));
        add(data, "Nashik",
            p("Panchavati and Kalaram Temple", "Historic temple quarter; observe local dress, access and photography rules.", "Heritage / Religious", 90, 20),
            p("Sula Vineyards", "Vineyard visit in the Gangapur area; tours and tastings require checking current schedules.", "Vineyard", 120, 35),
            p("Someshwar Waterfall and temple", "Seasonal riverside stop on the Godavari; avoid unsafe water conditions.", "Nature / Religious", 60, 30),
            p("Panchavati old-town walk", "Walk the historic riverfront and nearby market lanes at a relaxed pace.", "Town walk", 75, 15));
        add(data, "Shirdi",
            p("Dwarkamai", "Historic mosque associated with Sai Baba; follow shrine queue and visitor guidance.", "Religious / Heritage", 45, 10),
            p("Chavadi", "Historic pilgrimage stop linked to Sai Baba's life in Shirdi.", "Religious / Heritage", 35, 10),
            p("Lendi Baug", "Garden and memorial area within the Shirdi pilgrimage circuit.", "Garden / Religious", 40, 10),
            p("Gurusthan", "Sacred stop in the Shirdi temple precinct; follow current queue arrangements.", "Religious", 30, 10),
            p("Sai Heritage Village", "Themed heritage attraction on Shirdi's outskirts; check current operating status.", "Museum / Heritage", 90, 30));
        add(data, "Alibaug",
            p("Nagaon Beach", "Popular sandy beach south of Alibaug; allow a separate coastal drive.", "Beach", 90, 35),
            p("Varsoli Beach", "Quieter coastal stretch near Alibaug town for a relaxed shoreline visit.", "Beach", 75, 20),
            p("Kihim Beach", "Coastal village beach and nature stop north of town.", "Beach / Nature", 90, 30),
            p("Alibaug town market", "Local market and food stop near the town centre.", "Market / Food", 60, 15),
            p("Revdanda Fort and beach", "Coastal fort ruins and shoreline south of Alibaug; check tide and access.", "Fort / Beach", 100, 45));
        add(data, "Murud",
            p("Murud Beach", "Town beach for a relaxed coastal walk; observe local sea conditions.", "Beach", 75, 15),
            p("Garambi Falls", "Seasonal waterfall near Murud; best flow varies with rainfall.", "Waterfall", 60, 25),
            p("Kashid Beach", "Long sandy beach north of Murud; plan for a separate drive.", "Beach", 100, 40),
            p("Murud town and harbour walk", "Easy town-centre and harbour-side stroll with local food options.", "Town walk / Food", 60, 15),
            p("Datta Mandir viewpoint", "Hilltop temple viewpoint overlooking the Murud coastline.", "Viewpoint / Religious", 60, 25));
        add(data, "Harihareshwar",
            p("Harihareshwar temple precinct", "Coastal temple complex; confirm current darshan rules and timings.", "Religious / Heritage", 75, 10),
            p("Pradakshina coastal path", "Rocky shoreline circuit around the temple headland; use only when conditions are safe.", "Coastal walk", 90, 15),
            p("Harihareshwar beach", "Sandy shoreline for a short walk; avoid rough seas and restricted areas.", "Beach", 60, 15),
            p("Bankot Fort", "Historic fort across the creek; ferry/road access and timing need local confirmation.", "Fort / Heritage", 100, 55),
            p("Velas beach and village", "Nearby coastal village known for seasonal nature events; check dates and transport.", "Nature / Beach", 120, 60));
        add(data, "Ganpatipule",
            p("Aare-Ware coastal viewpoints", "Scenic Konkan road viewpoints between Ganpatipule and Ratnagiri.", "Viewpoint", 60, 35),
            p("Jaigad Fort and lighthouse", "Coastal fort area at the headland; verify lighthouse access locally.", "Fort / Heritage", 100, 45),
            p("Malgund village memorial", "Village heritage stop associated with Marathi poet Keshavsut.", "Heritage", 60, 15),
            p("Ganpatipule beach walk", "Shoreline visit beside the temple; follow tide and sea-safety guidance.", "Beach", 60, 10),
            p("Ratnagiri town viewpoint", "Optional longer drive for the Ratnagiri waterfront and local food.", "Town / Viewpoint", 90, 70));
        add(data, "Ratnagiri",
            p("Thiba Palace", "Historic palace museum and grounds associated with King Thibaw of Burma.", "Heritage / Museum", 75, 20),
            p("Ratnadurg (Bhagwati) Fort", "Coastal fort with sea views; allow time for the walk and check access.", "Fort / Viewpoint", 100, 25),
            p("Bhatye Beach", "Long beach near Ratnagiri town for an evening or morning walk.", "Beach", 75, 20),
            p("Thiba Point", "Coastal viewpoint near the palace and Ratnagiri waterfront.", "Viewpoint", 45, 15),
            p("Mandvi waterfront", "Harbour and shoreline promenade with local seafood options.", "Waterfront / Food", 60, 15));
        add(data, "Tarkarli",
            p("Tarkarli shoreline", "Long beach for a coastal walk; swimming and water activities depend on conditions.", "Beach", 90, 15),
            p("Deobagh village", "Quiet coastal village and estuary area near Tarkarli.", "Village / Nature", 75, 20),
            p("Tsunami Island", "Sandbar/estuary boat trip; water levels and services are seasonal.", "Boat / Nature", 120, 25),
            p("Karli River estuary", "Backwater scenery and boat route near the coast; confirm operators and safety.", "Nature / Boat", 90, 20),
            p("Tarkarli local seafood lane", "Meal stop for regional Malvani cuisine; restaurant hours vary.", "Food", 75, 15));
        add(data, "Malvan",
            p("Sindhudurg Fort", "Sea fort reached by boat from Malvan; boat service is weather and tide dependent.", "Fort / Heritage", 150, 30),
            p("Chivla Beach", "Town beach for a coastal walk near Malvan's harbour.", "Beach", 75, 15),
            p("Rock Garden", "Seafront garden and rocky coast lookout in Malvan.", "Garden / Viewpoint", 60, 15),
            p("Malvan fish market", "Local market stop to experience the coastal town's food culture.", "Market / Food", 45, 10),
            p("Devbag Sangam", "Coastal river-and-sea confluence near Malvan; allow for a separate drive.", "Nature / Viewpoint", 90, 35));
        add(data, "Kolhapur",
            p("Panhala Fort", "Large hill fort outside the city; allow a separate drive and walking time.", "Fort / Heritage", 150, 60),
            p("Jyotiba Temple", "Hilltop pilgrimage site northwest of Kolhapur; confirm current access.", "Religious", 90, 45),
            p("Town craft and jaggery market", "Local shopping stop for Kolhapuri crafts, footwear and food products.", "Market / Food", 60, 20),
            p("Bhavani Mandap", "Historic civic and religious landmark close to the Mahalaxmi precinct.", "Heritage", 45, 15),
            p("Kopeshwar Temple, Khidrapur", "Historic riverside temple outside Kolhapur; plan a longer drive.", "Heritage / Religious", 100, 75));
        add(data, "Nagpur",
            p("Zero Mile Stone", "Historic geographical marker in central Nagpur.", "Heritage", 30, 15),
            p("Maharajbagh Zoo and garden", "Central city garden and zoo; check current public opening information.", "Garden / Nature", 90, 20),
            p("Futala Lake", "Popular lakeside promenade and evening food area.", "Lake / Food", 75, 25),
            p("Dragon Palace Temple", "Buddhist temple complex at Kamptee, outside central Nagpur.", "Religious / Heritage", 90, 45),
            p("Sitabuldi Fort viewpoint", "Historic hilltop fort area; public access may be limited, confirm before visiting.", "Fort / Heritage", 45, 20));
        add(data, "Amravati",
            p("Ambadevi Temple", "Central Amravati temple and surrounding historic neighbourhood.", "Religious", 60, 15),
            p("Wadali Lake and garden", "Local lake and green space north of the city centre.", "Lake / Nature", 75, 25),
            p("Chatri Talao", "Historic reservoir and quiet city-side nature stop.", "Lake / Heritage", 60, 25),
            p("Upper Wardha Dam viewpoint", "Reservoir landscape outside the city; check access and plan a longer drive.", "Nature / Viewpoint", 90, 60),
            p("Amravati old-city market", "Local market and food walk near the central temple district.", "Market / Food", 60, 15));
        add(data, "Chhatrapati Sambhajinagar",
            p("Daulatabad (Deogiri) Fort", "Historic hill fort outside the city; allow several hours for the climb and site.", "Fort / Heritage", 180, 45),
            p("Panchakki", "Historic water mill and garden complex in the city.", "Heritage", 60, 20),
            p("Bhadra Maruti Temple", "Historic temple stop near Khuldabad; combine with a Daulatabad-area route.", "Religious / Heritage", 45, 45),
            p("Salim Ali Lake", "Urban wetland and birding stop; sightings depend on season.", "Nature", 60, 20),
            p("Himayat Bagh", "Historic garden and nursery area in the city; check visitor access.", "Garden / Heritage", 60, 20));
        add(data, "Ajanta Caves",
            p("Cave 9 and Cave 10", "Early Buddhist prayer halls with ancient architectural and mural features.", "Heritage / Caves", 75, 15),
            p("Cave 16", "Major monastery cave with sculptural and painted details.", "Heritage / Caves", 60, 10),
            p("Cave 17", "Monastery cave known for its wall paintings; follow site conservation rules.", "Heritage / Caves", 60, 10),
            p("Cave 26", "Large chaitya hall with a sculpted reclining Buddha.", "Heritage / Caves", 60, 15),
            p("Ajanta viewpoint", "Opposite-side viewpoint over the horseshoe-shaped gorge and cave façade.", "Viewpoint", 45, 15));
        add(data, "Ellora Caves",
            p("Dhumar Lena (Cave 29)", "Large rock-cut Hindu cave on the western side of the Ellora group.", "Heritage / Caves", 60, 15),
            p("Grishneshwar Temple", "Jyotirlinga temple near Ellora; respect current dress and visitor protocols.", "Religious / Heritage", 60, 20),
            p("Daulatabad Fort", "Historic hill fort near Ellora; allow a separate visit and climb.", "Fort / Heritage", 150, 45),
            p("Ellora north caves walk", "Explore additional Buddhist and Jain cave monuments at a measured pace.", "Heritage / Caves", 90, 15),
            p("Khuldabad heritage lane", "Short heritage-town stop near Ellora and Daulatabad.", "Heritage / Town walk", 60, 30));
        add(data, "Shani Shingnapur",
            p("Shani temple complex", "Main pilgrimage complex; follow current queue, footwear and photography rules.", "Religious", 75, 10),
            p("Shani museum and visitor area", "Local interpretive stop near the temple; confirm current public access.", "Heritage", 45, 10),
            p("Village market walk", "Short walk through the pilgrimage village and local shops.", "Town walk / Market", 45, 10),
            p("Nevasa (Newasa) temple area", "Nearby historic and pilgrimage area; plan a separate road transfer.", "Religious / Heritage", 75, 60),
            p("Ahmednagar Fort", "Historic fort in Ahmednagar city; best treated as a separate drive-day stop.", "Fort / Heritage", 90, 90));
        add(data, "Bhimashankar",
            p("Bhimashankar Wildlife Sanctuary trail", "Forest landscape around the shrine; follow current forest access guidance.", "Nature / Trek", 120, 25),
            p("Gupt Bhimashankar", "Forest trail to a stream-side shrine; conditions vary with rainfall.", "Nature / Religious", 120, 35),
            p("Nagphani (Duke's Nose) viewpoint", "Ridge viewpoint reached by a trek; only attempt in safe weather.", "Trek / Viewpoint", 150, 45),
            p("Hanuman Lake", "Small forest-side lake stop near the pilgrimage area.", "Lake / Nature", 45, 20),
            p("Bhorgiri Fort trail", "Nearby fort and village trail; allow a separate road transfer.", "Fort / Trek", 150, 60));
        add(data, "Trimbakeshwar",
            p("Kushavarta Kund", "Sacred water tank in the temple town; follow local customs and queue guidance.", "Religious / Heritage", 45, 10),
            p("Brahmagiri foothill trail", "Trek starting point for Brahmagiri; check weather and local trail advisories.", "Trek / Nature", 180, 25),
            p("Gangadwar", "Pilgrimage stop on the Brahmagiri hillside reached by steps.", "Religious / Trek", 90, 30),
            p("Anjaneri Fort trailhead", "Nearby hill trek associated with the Ramayana tradition; allow a separate drive.", "Trek / Heritage", 180, 40),
            p("Trimbak market lane", "Short town walk for local food and pilgrimage goods.", "Market / Food", 45, 10));
        add(data, "Igatpuri",
            p("Dhamma Giri Vipassana Centre", "Meditation centre and pagoda area; visitors must follow centre access rules.", "Meditation / Heritage", 75, 15),
            p("Camel Valley viewpoint", "Roadside valley lookout; monsoon visibility and roadside safety vary.", "Viewpoint", 45, 20),
            p("Tringalwadi Fort", "Hill fort and lake-view trek; confirm trail conditions before starting.", "Fort / Trek", 150, 35),
            p("Vihigaon Waterfall", "Seasonal waterfall near Igatpuri; access and flow vary by season.", "Waterfall", 75, 40),
            p("Bhatsa River valley lookout", "Scenic Western Ghats viewpoint near the highway; stop only at safe pull-offs.", "Viewpoint", 45, 25));
        add(data, "Bhandardara",
            p("Wilson Dam and Umbrella Falls", "Dam-side viewpoint and seasonal waterfall; the falls flow depends on releases and rain.", "Dam / Waterfall", 75, 20),
            p("Randha Falls", "Waterfall on the Pravara River; access and water conditions are seasonal.", "Waterfall", 60, 35),
            p("Agastya Rishi Ashram", "Riverside ashram area near the Pravara; observe local visitor customs.", "Religious / Nature", 45, 20),
            p("Kalsubai trek base (Bari)", "Starting village for the Kalsubai climb; the full trek is strenuous and needs planning.", "Trek", 180, 50),
            p("Ratangad Fort trailhead", "Fort trek access point in the Sahyadri landscape; check permits and trail conditions.", "Fort / Trek", 180, 60));
        add(data, "Tadoba-Andhari Tiger Reserve",
            p("Moharli safari gate", "Safari entry zone; advance permit, assigned time and gate rules apply.", "Wildlife Safari", 180, 25),
            p("Kolara safari gate", "Safari entry zone on the reserve's eastern side; use a valid booking.", "Wildlife Safari", 180, 60),
            p("Tadoba Lake zone", "Wildlife viewing area visited on authorized safari routes; sightings are not guaranteed.", "Wildlife", 120, 25),
            p("Pangdi / buffer safari area", "Buffer-area safari possibility subject to current booking and park rules.", "Wildlife Safari", 180, 45));
        add(data, "Pench National Park - Maharashtra",
            p("Sillari safari gate", "Maharashtra-side safari entry zone; check current permits and reporting time.", "Wildlife Safari", 180, 45),
            p("Khursapar safari gate", "Safari area accessed by permit; animal sightings and route are not guaranteed.", "Wildlife Safari", 180, 45),
            p("Pauni buffer zone", "Buffer-zone forest visit subject to current availability and park rules.", "Wildlife Safari", 180, 50),
            p("Pench forest interpretation stop", "Plan a rest and interpretation stop at the authorized visitor area.", "Nature / Visitor centre", 60, 20));
        add(data, "Torna Fort",
            p("Zunjar Machi ridge", "Fort ridge section reached on the Torna trek; proceed only with daylight and safe weather.", "Fort / Trek", 75, 20),
            p("Budhla Machi", "Historic fort spur on the Torna plateau; exposed paths need care.", "Fort / Trek", 75, 20),
            p("Menghai Devi Temple", "Small temple within the Torna fort area.", "Religious / Heritage", 30, 20),
            p("Torna plateau circuit", "Walk the main plateau and ramparts at a conservative pace.", "Fort / Trek", 90, 20),
            p("Velhe base village", "Use the village as a route briefing and post-trek rest stop.", "Village / Rest stop", 45, 15));
        add(data, "Raigad Fort",
            p("Maha Darwaja", "Main historic entrance to the fort plateau.", "Fort / Heritage", 45, 15),
            p("Raj Bhavan and Nagarkhana", "Historic royal precinct and drum-house area on the fort.", "Fort / Heritage", 60, 15),
            p("Hirkani Buruj", "Fort wall and lookout associated with local history.", "Fort / Viewpoint", 45, 20),
            p("Takmak Tok", "Cliff-edge viewpoint; stay behind barriers and follow safety signage.", "Viewpoint", 45, 20),
            p("Jagadishwar Temple and Samadhi", "Historic temple and memorial precinct on the Raigad plateau.", "Heritage / Religious", 60, 15));
        add(data, "Pratapgad Fort",
            p("Bhavani Mata Temple", "Temple within the Pratapgad fort complex; follow visitor guidance.", "Religious / Heritage", 45, 15),
            p("Afzal Khan memorial area", "Historic memorial stop associated with the fort's Maratha-era history.", "Heritage", 45, 15),
            p("Fort ramparts and bastions", "Walk the fort walls and bastions using marked paths.", "Fort / Heritage", 75, 20),
            p("Pratapgad viewpoint", "Lookout over the surrounding forested hills.", "Viewpoint", 45, 15),
            p("Wai heritage town", "Optional longer drive to Wai's riverside ghats and historic town centre.", "Heritage / Town walk", 90, 75));
        add(data, "Sinhagad Fort",
            p("Kalyan Darwaza", "Historic fort gateway on the quieter approach side.", "Fort / Heritage", 45, 20),
            p("Tanaji memorial", "Memorial site on the fort associated with the battle of Sinhagad.", "Heritage", 30, 15),
            p("Dev Take water cisterns", "Historic water-storage features within the fort precinct.", "Heritage", 30, 15),
            p("Fort plateau food stalls", "Rest stop for local snacks; availability and hours vary.", "Food / Rest stop", 45, 15),
            p("Khadakwasla Dam viewpoint", "Reservoir viewpoint on the return route toward Pune.", "Viewpoint", 45, 35));
        add(data, "Devkund Waterfall",
            p("Bhira village trailhead", "Starting point for the Devkund trek; confirm current permissions and guide rules.", "Trek", 30, 15),
            p("Devkund forest trail", "Forest walk to the waterfall; trail time and difficulty vary by conditions.", "Trek / Nature", 150, 30),
            p("Kundalika valley viewpoint", "Scenic valley stop near the Bhira region.", "Viewpoint", 45, 20),
            p("Bhira Dam area", "Reservoir and dam-side scenery; public access is restricted in some areas.", "Dam / Nature", 45, 25),
            p("Tamhini Ghat viewpoints", "Monsoon mountain-road scenery; stop only at safe, permitted pull-offs.", "Viewpoint", 90, 50));
        add(data, "Lonar Lake",
            p("Daitya Sudan Temple", "Historic temple near Lonar town noted for its carved stone architecture.", "Heritage / Religious", 60, 15),
            p("Lonar crater rim viewpoint", "Lookout over the meteor-impact crater and lake basin.", "Geology / Viewpoint", 60, 20),
            p("Crater descent trail", "Steep trail toward the lake; use suitable footwear and check local access rules.", "Trek / Geology", 180, 25),
            p("Gomukh Temple and stream", "Religious and geological site near the crater slope.", "Religious / Nature", 45, 25),
            p("Lonar salt lake interpretation", "Observe the crater's saline lake ecology from authorized viewpoints.", "Nature / Geology", 60, 20));
        add(data, "Amboli",
            p("Amboli Waterfall", "Seasonal roadside waterfall; monsoon crowds and road conditions need care.", "Waterfall", 60, 20),
            p("Sunset Point", "Western Ghats viewpoint overlooking the Konkan on clear evenings.", "Viewpoint", 45, 15),
            p("Nangarta Falls", "Waterfall and gorge viewpoint outside the town centre.", "Waterfall", 60, 30),
            p("Hiranyakeshi Temple and source", "Temple and stream source area south of Amboli; access can be seasonal.", "Religious / Nature", 75, 35),
            p("Kavlesad Point", "Cliff viewpoint with valley scenery; verify safe access before visiting.", "Viewpoint", 45, 20));
        add(data, "Sawantwadi",
            p("Moti Talav", "Central lake and walking area beside Sawantwadi town.", "Lake / Town walk", 60, 15),
            p("Sawantwadi Palace craft centre", "Palace and traditional Ganjifa craft area; verify visitor access.", "Heritage / Craft", 75, 15),
            p("Wooden toy workshops", "Local craft stop for Sawantwadi's painted wooden toys; ask before photographing.", "Craft / Market", 60, 15),
            p("Narendra Hill viewpoint", "Hilltop view above Sawantwadi with a short road approach.", "Viewpoint", 60, 25),
            p("Town bazaar walk", "Compact market walk for local produce and Malvani snacks.", "Market / Food", 60, 15));
        add(data, "Jawhar",
            p("Jai Vilas Palace", "Historic palace and museum associated with the former princely state.", "Heritage / Museum", 75, 15),
            p("Dabhosa Waterfall viewpoint", "Seasonal waterfall outside town; access and water flow vary.", "Waterfall", 75, 35),
            p("Hanuman Point", "Hilltop viewpoint above the Jawhar landscape.", "Viewpoint", 45, 15),
            p("Shirpamal", "Historic site associated with Shivaji Maharaj's visit to the region.", "Heritage", 45, 20),
            p("Warli art and local craft stop", "Explore regional Warli art through local community or craft centres when open.", "Culture / Craft", 75, 20));
        add(data, "Akkalkot",
            p("Vatavruksha Swami Samarth Temple", "Major pilgrimage complex associated with Shri Swami Samarth; follow current darshan guidance.", "Religious", 90, 15),
            p("Swami Samarth Math", "Pilgrimage and memorial precinct in Akkalkot; expect visitor queues at busy times.", "Religious / Heritage", 75, 15),
            p("Samadhi Math area", "Important devotional stop in the town pilgrimage circuit.", "Religious", 60, 15),
            p("Akkalkot old-town walk", "Short walk through the temple town and local market streets.", "Town walk / Market", 60, 15),
            p("Borgaon pilgrimage stop", "Optional nearby regional religious visit; confirm road conditions and local timings.", "Religious", 60, 40));
        add(data, "Nanded",
            p("Takht Sachkhand Sri Hazur Abchalnagar Sahib", "Major Sikh takht and pilgrimage complex; respect current visitor protocols.", "Religious / Heritage", 100, 15),
            p("Gobind Bagh", "Garden and memorial area connected with the Hazur Sahib complex.", "Garden / Heritage", 45, 15),
            p("Nanded Fort and Godavari riverfront", "Historic fort area beside the river; check public access locally.", "Fort / Riverfront", 75, 20),
            p("Kaleshwar Temple, Vishnupuri", "Riverside temple stop outside the central city.", "Religious", 60, 35),
            p("Nanded old-town bazaar", "Market and food walk near the central pilgrimage district.", "Market / Food", 60, 15));
        add(data, "Tuljapur",
            p("Tulja Bhavani Temple", "Main pilgrimage temple; check the current darshan queue and visitor requirements.", "Religious / Heritage", 100, 10),
            p("Ghatshila Temple", "Hill-side shrine near Tuljapur associated with the local pilgrimage circuit.", "Religious", 60, 20),
            p("Chintamani Temple", "Small shrine within the town's pilgrimage area.", "Religious", 30, 10),
            p("Kallol Tirth", "Sacred water site in the temple town; observe local access rules.", "Religious", 30, 10),
            p("Tuljapur bazaar", "Market walk for local food and pilgrimage offerings.", "Market / Food", 60, 15));
        add(data, "Pandharpur",
            p("Chandrabhaga river ghats", "Riverside ghats near the Vitthal temple; take care during high water.", "Riverfront / Religious", 60, 15),
            p("Pundalik Temple", "Small temple on the riverfront pilgrimage route.", "Religious", 45, 15),
            p("ISKCON Pandharpur", "Temple and visitor complex outside the old-town centre; check visitor guidance.", "Religious", 75, 25),
            p("Kaikadi Maharaj Math", "Religious and cultural complex in Pandharpur.", "Religious / Culture", 60, 20),
            p("Wari route and old-town walk", "Walk a section of the historic pilgrimage streets at a quiet time.", "Town walk / Heritage", 60, 15));
        add(data, "Solapur",
            p("Solapur Bhuikot Fort", "Historic fort in central Solapur; confirm current public access.", "Fort / Heritage", 75, 20),
            p("Great Indian Bustard Sanctuary", "Grassland conservation landscape outside the city; viewing depends on access and season.", "Nature / Wildlife", 120, 65),
            p("Solapur textile and chaddar market", "Local textile market for the city's well-known woven products.", "Market / Craft", 75, 20),
            p("Siddheshwar Lake walk", "Lakeside walk near the temple precinct.", "Lake / Town walk", 45, 15),
            p("Akkalkot road-side food stop", "Optional regional food and pilgrimage stop on a separate drive.", "Food / Day trip", 60, 45));
        add(data, "Wardha",
            p("Sevagram Ashram", "Gandhi's ashram and museum; follow visitor timings and conduct guidance.", "Heritage / Museum", 120, 20),
            p("Pavnar Ashram", "Vinoba Bhave's ashram on the Dham River.", "Heritage / Religious", 75, 25),
            p("Magan Sangrahalaya", "Museum focused on rural industries and Gandhian ideas.", "Museum", 75, 15),
            p("Vishwa Shanti Stupa", "Peace pagoda and garden at Wardha.", "Religious / Viewpoint", 60, 20),
            p("Wardha town heritage walk", "Short town-centre walk through civic and market areas.", "Town walk", 60, 15));
        add(data, "Melghat",
            p("Semadoh nature area", "Forest and reservoir region; entry and activities require current local guidance.", "Nature / Wildlife", 120, 40),
            p("Chikhaldara forest viewpoints", "Forest lookout route in the Melghat landscape; travel time depends on road conditions.", "Viewpoint / Nature", 120, 60),
            p("Gugamal National Park access zone", "Protected-area visit subject to permits, season and forest-department rules.", "Wildlife", 180, 60),
            p("Sipna River valley", "Forest river scenery viewed from authorized public areas.", "Nature", 75, 35),
            p("Korku culture interpretation stop", "Learn about local Korku culture through authorized community or interpretation centres.", "Culture", 75, 30));
        add(data, "Chikhaldara",
            p("Bhimkund-Kichakdara", "Waterfall and gorge viewpoint linked to the area's local legend.", "Waterfall / Viewpoint", 60, 20),
            p("Gawilgad Fort", "Historic hill fort with forest views; check access and allow time for walking.", "Fort / Heritage", 120, 30),
            p("Panchbol Point", "Valley viewpoint with echo effects in suitable conditions.", "Viewpoint", 45, 15),
            p("Devi Point", "Viewpoint over the Satpura landscape near Chikhaldara.", "Viewpoint", 45, 15),
            p("Muktagiri Jain pilgrimage site", "Hill-side temple complex on the Madhya Pradesh border; plan a separate drive.", "Religious / Heritage", 120, 70));
        add(data, "Dapoli",
            p("Harnai fish market and harbour", "Coastal harbour and fish auction area; visit timing varies with the catch.", "Harbour / Market", 60, 25),
            p("Anjarle beach and Kadyavarcha Ganpati", "Coastal beach and hilltop temple near Anjarle village.", "Beach / Religious", 100, 35),
            p("Murud-Harnai beach", "Long sandy beach north of Dapoli town.", "Beach", 75, 25),
            p("Karde Beach", "Popular coastal stretch near Dapoli; sea conditions vary.", "Beach", 75, 25),
            p("Parshuram Bhumi", "Large coastal statue and viewpoint near Burondi; verify current opening access.", "Viewpoint / Heritage", 60, 35));
        add(data, "Diveagar",
            p("Diveagar beach walk", "Long sandy shoreline; follow local sea-safety and turtle-nesting restrictions.", "Beach / Nature", 90, 15),
            p("Suvarna Ganesh temple area", "Temple stop in Diveagar; confirm current site access and local customs.", "Religious / Heritage", 60, 15),
            p("Shrivardhan beach and town", "Nearby coastal town and beach; allow for a separate road transfer.", "Beach / Town walk", 100, 40),
            p("Harihareshwar coastal temple", "Nearby pilgrimage and coastal walk; check tide and path conditions.", "Religious / Beach", 120, 60),
            p("Diveagar village market", "Local village shops and food stop near the coast.", "Market / Food", 45, 15));
        add(data, "Kamshet",
            p("Pawna Lake", "Reservoir and camping landscape; operators, access and swimming rules vary.", "Lake / Nature", 90, 35),
            p("Karla Caves", "Ancient Buddhist caves near the highway; climb involves a long set of steps.", "Heritage / Caves", 100, 35),
            p("Bedsa Caves", "Rock-cut Buddhist caves reached by a hillside walk.", "Heritage / Trek", 120, 40),
            p("Uksan Lake", "Quiet lake-side scenery near Kamshet.", "Lake / Nature", 60, 25),
            p("Paragliding launch area", "Tandem flights operate only with licensed operators and suitable weather; check current availability.", "Adventure", 120, 30));
        add(data, "Lavasa",
            p("Lakeside promenade", "Walk the waterfront promenade; verify current public access and services before travel.", "Lake / Town walk", 75, 15),
            p("Dasve town centre", "Explore the planned town's central streets and public-facing architecture.", "Town walk / Architecture", 60, 15),
            p("Temghar Dam viewpoint", "Reservoir scenery on the approach road; stay in authorized public areas.", "Dam / Viewpoint", 45, 30),
            p("Varasgaon reservoir outlook", "Scenic reservoir-side drive with limited public stopping points.", "Nature / Viewpoint", 60, 35),
            p("Lakeside meal stop", "Plan a meal break around currently open food services; check availability in advance.", "Food / Rest stop", 60, 15));
        return data;
    }

    private static void add(Map<String, List<Place>> data, String destination, Place... places) {
        data.put(destination, new ArrayList<>(List.of(places)));
    }
}
