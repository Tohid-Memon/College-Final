package com.maharashtra.tourism.controller;

import com.maharashtra.tourism.dto.MapDtos.GeocodedPlace;
import com.maharashtra.tourism.dto.MapDtos.NearbyPlace;
import com.maharashtra.tourism.dto.MapDtos.RoutePlan;
import com.maharashtra.tourism.dto.MapDtos.RouteRequest;
import com.maharashtra.tourism.service.MappingService;
import jakarta.servlet.http.HttpServletRequest;
import java.time.Duration;
import java.util.List;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/maps")
public class MappingController {
    private final MappingService mappings;

    public MappingController(MappingService mappings) {
        this.mappings = mappings;
    }

    @GetMapping("/geocode")
    public GeocodedPlace geocode(@RequestParam String query) {
        return mappings.geocode(query);
    }

    @GetMapping("/nearby")
    public List<NearbyPlace> nearby(
        @RequestParam double latitude,
        @RequestParam double longitude,
        @RequestParam(defaultValue = "10") int radiusKm,
        @RequestParam(required = false) String placeName
    ) {
        return mappings.nearby(latitude, longitude, radiusKm, placeName);
    }

    @GetMapping(value = "/tiles/{z}/{x}/{y}.png", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> tile(
        @PathVariable int z,
        @PathVariable int x,
        @PathVariable int y,
        HttpServletRequest request
    ) {
        byte[] tile = mappings.tile(z, x, y, request.getHeader("Referer"));
        return ResponseEntity.ok()
            .cacheControl(CacheControl.maxAge(Duration.ofDays(7)).cachePrivate())
            .contentType(MediaType.IMAGE_PNG)
            .body(tile);
    }

    @PostMapping("/route")
    public RoutePlan route(@RequestBody RouteRequest request) {
        return mappings.route(request);
    }
}
