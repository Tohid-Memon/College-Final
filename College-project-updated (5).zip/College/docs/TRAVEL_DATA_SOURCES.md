# Travel data sources and limits

## Nearby places and routes

The separate trip planner uses OpenStreetMap data for map tiles and nearby place names. Search is user-triggered, results are cached by the app, and the map displays OpenStreetMap attribution. Its public Nominatim and tile services have fair-use requirements and no service-level guarantee; the app keeps their base URLs configurable so an operator can switch providers. Nearby searches use the public Overpass service with a bounded radius and cached results. Road ordering and geometry use the public OSRM demo service, which is restricted to reasonable non-commercial use, at most one request per second, and has no uptime guarantee. This is appropriate only for a small demonstration; a larger/public deployment should use provider agreements or self-hosted/capacity-backed services.

## Hotel prices

The app does not fabricate hotel names or rates. The current project has no approved accommodation API credentials. The route page therefore opens a date- and guest-specific Booking.com search for current property inventory and prices; the provider page is where availability, final price, taxes, room terms, cancellation, and booking are confirmed. Displaying those prices inside this app requires affiliate/partner access and server-side credentials. Booking.com Demand API access is for Affiliate Partners and uses Affiliate ID/token credentials; Expedia Rapid applications are reviewed case by case. Credentials must be stored server-side and never committed to source or exposed to browser code.

## Official references

- OpenStreetMap Nominatim policy: https://operations.osmfoundation.org/policies/nominatim/
- OpenStreetMap tile policy: https://operations.osmfoundation.org/policies/tiles/
- Overpass public-instance guidance: https://dev.overpass-api.de/overpass-doc/en/preface/commons.html
- OSRM route API: https://project-osrm.org/docs/v5.24.0/api/
- OSRM demo-server policy: https://github.com/Project-OSRM/osrm-backend/wiki/Demo-server
- Booking.com Demand API: https://developers.booking.com/demand/docs/open-api/3.2/demand-api
- Expedia Rapid partner access: https://partner.expediagroup.com/en-us/join-us/rapid-api

The tile proxy requests the exact `tile.openstreetmap.org/{z}/{x}/{y}.png` URL using a stable `MaharashtraTrails` User-Agent, forwards the route page Referer, stores returned tiles under `data/osm-tiles`, and sends a seven-day private browser cache header. It does not prefetch tiles or offer offline maps.

## Car-free route areas

The route API uses OSRM driving-time ordering only when it returns non-degenerate road distances. If distinct selected locations all collapse to one road point, the app instead orders them by straight-line distance and shows a conservative 3 km/h walking-time estimate with straight-line geometry. This is a planning fallback, not a mapped pedestrian route; users are warned to verify real local paths/access. The external Google Maps link switches to walking mode for this fallback.
