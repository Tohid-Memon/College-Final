const API = '/api';
const state = {
  destinations: [],
  filtered: [],
  category: 'All',
  showAll: false,
  selected: null,
  suggestionTimer: null,
};
let csrfToken = null;
const $ = (id) => document.getElementById(id);
const escapeHtml = (value = '') => String(value).replace(/[&<>"']/g, (ch) => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
}[ch]));
const money = (value) => new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
}).format(Number(value) || 0);
const durationLabel = (value) => {
  const minutes = Math.max(0, Number(value) || 0);
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  return `${hours} hr${hours === 1 ? '' : 's'}${remainder ? ` ${remainder} min` : ''}`;
};

function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2600);
}

async function getCsrfToken() {
  if (csrfToken) return csrfToken;
  const response = await fetch(`${API}/auth/csrf`, { credentials: 'same-origin' });
  let body = {};
  try { body = await response.json(); } catch { /* handled below */ }
  if (!response.ok || !body.token) {
    throw new Error(body.message || 'Could not initialize a secure session. Refresh and try again.');
  }
  csrfToken = body.token;
  return csrfToken;
}

async function getJson(url, options = {}) {
  const method = (options.method || 'GET').toUpperCase();
  const headers = { Accept: 'application/json', ...(options.headers || {}) };
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
    headers['X-XSRF-TOKEN'] = await getCsrfToken();
  }
  const response = await fetch(url, {
    ...options,
    method,
    headers,
    credentials: 'same-origin',
  });
  let body = {};
  if (response.status !== 204) {
    try { body = await response.json(); }
    catch { body = { message: 'The server returned an unexpected response.' }; }
  }
  if (!response.ok) {
    const error = new Error(body.message || 'Request failed. Please try again.');
    error.status = response.status;
    if (response.status === 401 && !url.includes('/api/auth/')) {
      showAuthGate('Your session expired. Sign in again.');
    }
    throw error;
  }
  return body;
}

function categoryClass(category = '') {
  const c = category.toLowerCase();
  if (c.includes('beach') || c.includes('coast')) return 'beach';
  if (c.includes('heritage') || c.includes('fort')) return 'heritage';
  if (c.includes('city')) return 'city';
  return 'hill';
}

const destinationImageTemplates = new Map(
  [...document.querySelectorAll('#destination-image-templates template')]
    .map((template) => [template.dataset.destination, template]),
);

function createDestinationCard(destination) {
  const template = $('destination-card-template');
  const card = template.content.firstElementChild.cloneNode(true);
  const visual = card.querySelector('.destination-visual');
  const imageTemplate = destinationImageTemplates.get(destination.name);
  const image = imageTemplate?.content.querySelector('img')?.cloneNode(true);
  const days = Number(destination.recommendedDays) || 1;

  card.dataset.id = destination.id;
  card.setAttribute('aria-label', `Explore ${destination.name}`);
  visual.classList.add(categoryClass(destination.category || ''));
  card.querySelector('[data-card-name]').textContent = destination.name;
  card.querySelector('[data-card-description]').textContent = destination.description || 'Explore this Maharashtra destination.';
  card.querySelector('[data-card-district]').textContent = `⌖ ${destination.district || 'Maharashtra'}`;
  card.querySelector('[data-card-days]').textContent = `${days} day${days === 1 ? '' : 's'} suggested`;
  card.querySelector('[data-card-category]').textContent = (destination.category || 'EXPLORE').toUpperCase();

  if (image) {
    image.addEventListener('error', () => {
      image.remove();
      visual.classList.add('photo-missing');
    }, { once: true });
    visual.insertBefore(image, card.querySelector('[data-card-category]'));
  }

  return card;
}

function filteredDestinations() {
  let list = state.destinations;
  if (state.category !== 'All') {
    list = list.filter((d) => (d.category || '').toLowerCase().includes(state.category.toLowerCase()));
  }
  return list;
}

function renderDestinations() {
  const all = filteredDestinations();
  state.filtered = all;
  const shown = state.showAll ? all : all.slice(0, 8);
  $('destination-status').textContent = `Showing ${shown.length} of ${all.length} destinations from the project database.`;
  const grid = $('destination-grid');
  grid.replaceChildren();
  if (shown.length) {
    shown.forEach((destination) => grid.append(createDestinationCard(destination)));
  } else {
    const emptyMessage = document.createElement('p');
    emptyMessage.textContent = 'No destinations match this filter.';
    grid.append(emptyMessage);
  }
  $('show-all').classList.toggle('hidden', all.length <= 8);
  $('show-all').textContent = state.showAll ? 'Show fewer destinations ↑' : 'Show all destinations →';
  grid.querySelectorAll('.destination-card').forEach((card) => {
    const open = () => openDestination(Number(card.dataset.id));
    card.addEventListener('click', open);
    card.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        open();
      }
    });
  });
}

async function loadDestinations() {
  try {
    state.destinations = await getJson(`${API}/destinations`);
    renderDestinations();
    $('budget-destination').innerHTML = '<option value="">Choose a destination</option>'
      + state.destinations.map((d) => `<option value="${d.id}">${escapeHtml(d.name)}</option>`).join('');
    $('destination-status').textContent = `${state.destinations.length} destinations ready to explore.`;
  } catch (error) {
    if (error.status === 401) return;
    $('destination-status').textContent = 'Could not load destinations. Check that the Spring Boot application is running, then refresh.';
    $('destination-grid').innerHTML = `<p>${escapeHtml(error.message)}</p>`;
  }
}

function renderSuggestions(items) {
  const el = $('suggestions');
  if (!items.length) {
    el.innerHTML = '<div class="suggestion">No matching destinations. Try another Maharashtra place.</div>';
    el.classList.remove('hidden');
    return;
  }
  el.innerHTML = items.slice(0, 6).map((d) => `
    <button class="suggestion" type="button" data-id="${d.id}">
      <span>${escapeHtml(d.name)}</span><small>${escapeHtml(d.category || 'Destination')}</small>
    </button>`).join('');
  el.classList.remove('hidden');
  el.querySelectorAll('button[data-id]').forEach((button) => {
    button.addEventListener('click', () => {
      const destination = state.destinations.find((item) => item.id === Number(button.dataset.id));
      $('search-input').value = destination?.name || '';
      el.classList.add('hidden');
      if (destination) openDestination(destination.id);
    });
  });
}

$('search-input').addEventListener('input', () => {
  clearTimeout(state.suggestionTimer);
  const query = $('search-input').value.trim();
  if (!query) {
    $('suggestions').classList.add('hidden');
    return;
  }
  state.suggestionTimer = setTimeout(async () => {
    try { renderSuggestions(await getJson(`${API}/destinations/search?query=${encodeURIComponent(query)}`)); }
    catch { $('suggestions').classList.add('hidden'); }
  }, 180);
});

document.addEventListener('click', (event) => {
  if (!event.target.closest('.searchbar')) $('suggestions').classList.add('hidden');
});

$('search-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const query = $('search-input').value.trim();
  if (!query) {
    toast('Enter a destination to search.');
    $('search-input').focus();
    return;
  }
  try {
    const items = await getJson(`${API}/destinations/search?query=${encodeURIComponent(query)}`);
    $('suggestions').classList.add('hidden');
    if (!items.length) {
      showUnknown(query);
      return;
    }
    const exact = items.find((d) => d.name.toLowerCase() === query.toLowerCase());
    await openDestination((exact || items[0]).id);
  } catch (error) {
    if (error.status !== 401) showUnknown(query, error.message);
  }
});

function showUnknown(query, message) {
  $('detail-section').classList.remove('hidden');
  $('detail-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
  $('detail-title').textContent = 'Destination not found';
  $('detail-description').textContent = message || `We don't have information about “${query}” yet. Please check the spelling or try another Maharashtra destination.`;
  $('detail-meta').innerHTML = '<span class="meta-pill">No matching destination</span><span class="meta-pill">Try a popular place below</span>';
  $('attraction-list').innerHTML = '<div class="info-item"><strong>Popular destinations</strong><p>Choose a place to open its guide:</p><div class="quick-destinations">'
    + state.destinations.filter((d) => ['Matheran', 'Lonavala', 'Mahabaleshwar', 'Pune', 'Mumbai', 'Alibaug'].includes(d.name))
      .map((d) => `<button type="button" class="filter" data-quick-id="${d.id}">${escapeHtml(d.name)}</button>`).join('')
    + '</div></div>';
  $('attraction-list').querySelectorAll('[data-quick-id]').forEach((button) => {
    button.addEventListener('click', () => openDestination(Number(button.dataset.quickId)));
  });
  $('hotel-list').innerHTML = '<div class="info-item"><strong>No hotel suggestions available</strong><p>Search a supported destination to view sample stay suggestions.</p></div>';
  $('itinerary-output').innerHTML = '';
}

async function openDestination(id) {
  try {
    const destination = await getJson(`${API}/destinations/${id}`);
    state.selected = destination;
    $('route-planner-link').href = `route-planner.html?destinationId=${encodeURIComponent(destination.id)}#stays`;
    $('detail-section').classList.remove('hidden');
    $('detail-title').textContent = destination.name;
    $('detail-description').textContent = destination.description || 'Destination details are limited in this demo.';
    $('detail-meta').innerHTML = [
      destination.district ? `⌖ ${destination.district}` : 'Maharashtra',
      destination.category || 'Destination',
      destination.bestTime ? `Best time: ${destination.bestTime}` : 'Best time: unavailable',
      `${destination.recommendedDays || 1} suggested day(s)`,
    ].map((item) => `<span class="meta-pill">${escapeHtml(item)}</span>`).join('');
    $('budget-destination').value = String(destination.id);
    $('itinerary-output').innerHTML = '';
    const [attractions, hotels] = await Promise.all([
      getJson(`${API}/destinations/${id}/attractions`),
      getJson(`${API}/destinations/${id}/hotels`),
    ]);
    $('attraction-list').innerHTML = attractions.length ? attractions.map((a) => `
      <div class="info-item"><strong>${escapeHtml(a.name)}</strong><p>${escapeHtml(a.description || 'Details unavailable.')}</p>
      <span class="item-meta">${escapeHtml(a.category || 'Attraction')} · ${a.visitMinutes ? `${durationLabel(a.visitMinutes)} visit` : 'Allow about 1 hr'} · ${a.entryFee == null ? 'check current fee' : `Entry: ${money(a.entryFee)}`}</span></div>`).join('')
      : '<div class="info-item"><strong>Attraction details not available yet</strong><p>We have not added attraction records for this destination in the demo database.</p></div>';
    $('hotel-list').innerHTML = hotels.length ? hotels.map((hotel) => `
      <div class="info-item"><strong>${escapeHtml(hotel.name)}</strong><p>${escapeHtml(hotel.description || 'Sample hotel suggestion.')}</p>
      <span class="item-meta">${escapeHtml(hotel.category)} planning band · ${money(hotel.pricePerNight)} / night · ${escapeHtml(hotel.facilities || 'Confirm facilities locally')}</span></div>`).join('')
      : '<div class="info-item"><strong>No sample hotels yet</strong><p>This destination has no hotel suggestions in the sample data.</p></div>';
    $('detail-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    if (error.status === 401) return;
    if (error.message.toLowerCase().includes('destination not found')) showUnknown('');
    else toast(error.message);
  }
}

$('close-detail').addEventListener('click', () => {
  $('detail-section').classList.add('hidden');
  $('destinations').scrollIntoView({ behavior: 'smooth' });
});

$('filter-pills').querySelectorAll('button').forEach((button) => {
  button.addEventListener('click', () => {
    state.category = button.dataset.category;
    state.showAll = false;
    $('filter-pills').querySelectorAll('button').forEach((item) => item.classList.toggle('active', item === button));
    renderDestinations();
  });
});

$('show-all').addEventListener('click', () => {
  state.showAll = !state.showAll;
  renderDestinations();
});

$('travellers').addEventListener('change', () => {
  const travellers = Math.max(1, Number($('travellers').value) || 1);
  $('rooms').value = Math.ceil(travellers / 2);
});

$('budget-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('budget-error').textContent = '';
  const data = {
    travellers: Number($('travellers').value),
    days: Number($('days').value),
    hotelCategory: $('hotel-category').value,
    rooms: Number($('rooms').value),
    transportation: Number($('transport').value),
    dailyFoodPerPerson: Number($('food').value),
    miscellaneous: Number($('misc').value),
  };
  if (!Number.isInteger(data.travellers) || data.travellers < 1
      || !Number.isInteger(data.rooms) || data.rooms < 1
      || !Number.isInteger(data.days) || data.days < 1
      || [data.transportation, data.dailyFoodPerPerson, data.miscellaneous].some((value) => !Number.isFinite(value) || value < 0)) {
    $('budget-error').textContent = 'Use at least one traveller and room, and enter zero or a positive amount for every cost.';
    return;
  }
  try {
    const result = await getJson(`${API}/budget/calculate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    $('total-cost').textContent = money(result.total);
    $('per-person').textContent = `${money(result.perPerson)} per person · ${result.nights} hotel night(s)`;
    $('cost-breakdown').innerHTML = [
      ['Accommodation', result.accommodation],
      ['Food', result.food],
      ['Transportation', result.transportation],
      ['Miscellaneous', result.miscellaneous],
    ].map(([label, value]) => `<div class="cost-row"><span>${label}</span><strong>${money(value)}</strong></div>`).join('');
    $('budget-result').classList.remove('hidden');
  } catch (error) {
    if (error.status !== 401) $('budget-error').textContent = error.message;
  }
});

let budgetWasCalculated = false;
$('budget-form').addEventListener('submit', () => { budgetWasCalculated = true; });
['travellers', 'days', 'hotel-category', 'rooms', 'transport', 'food', 'misc'].forEach((id) => {
  $(id).addEventListener('change', () => {
    if (budgetWasCalculated) $('budget-form').requestSubmit();
  });
});

$('make-itinerary').addEventListener('click', async () => {
  if (!state.selected) {
    toast('Open a destination first to build its itinerary.');
    return;
  }
  const button = $('make-itinerary');
  const originalLabel = button.textContent;
  button.disabled = true;
  button.textContent = 'Planning route…';
  $('itinerary-output').innerHTML = '<p class="itinerary-status">Building a timed route with visit and transfer estimates…</p>';
  try {
    const days = Number($('itinerary-days').value);
    const result = await getJson(`${API}/destinations/${state.selected.id}/itinerary?days=${days}`);
    const plan = result.plan || [];
    $('itinerary-output').innerHTML = plan.length ? plan.map((day) => `
      <article class="day-plan">
        <h4><span>Day ${day.day}</span><small>${escapeHtml(day.startTime || '')}–${escapeHtml(day.endTime || '')}</small></h4>
        <ol class="day-timeline">${day.activities.map((activity) => `
          <li class="timeline-stop ${activity.category === 'Meal / rest break' ? 'timeline-break' : ''}">
            <time>${escapeHtml(activity.startTime || activity.period || '')}<span>${escapeHtml(activity.endTime || '')}</span></time>
            <div class="timeline-copy"><strong>${escapeHtml(activity.attraction)}</strong>
              <p>${escapeHtml(activity.description || '')}</p>
              <small>${escapeHtml(activity.category || 'Visit')} · ${durationLabel(activity.durationMinutes)}${Number(activity.travelMinutes) > 0 ? ` · about ${durationLabel(activity.travelMinutes)} transfer` : ''}${activity.entryFee != null ? ` · entry ${money(activity.entryFee)}` : ''}</small>
            </div>
          </li>`).join('')}</ol>
        <div class="day-summary">${day.visitCount} visit${day.visitCount === 1 ? '' : 's'} · about ${durationLabel(day.durationMinutes)} including breaks and transfers</div>
      </article>`).join('')
      : `<div class="day-plan"><p>${escapeHtml(result.message || 'No itinerary data available yet.')}</p></div>`;
    if (result.note) $('itinerary-output').insertAdjacentHTML('beforeend', `<p class="itinerary-note">${escapeHtml(result.note)}</p>`);
  } catch (error) {
    if (error.status !== 401) toast(error.message);
    $('itinerary-output').innerHTML = `<p class="itinerary-status error-text">${escapeHtml(error.message || 'Could not build the itinerary. Please try again.')}</p>`;
  } finally {
    button.disabled = false;
    button.textContent = originalLabel;
  }
});

const authForm = $('auth-form');
const authName = $('auth-name');
const authEmail = $('auth-email');
const authPassword = $('auth-password');
const authConfirmPassword = $('auth-confirm-password');
const authFeedback = $('auth-feedback');
let authMode = 'login';

function setAuthMode(mode) {
  authMode = mode;
  const isSignup = mode === 'signup';
  $('login-tab').classList.toggle('active', !isSignup);
  $('signup-tab').classList.toggle('active', isSignup);
  $('login-tab').setAttribute('aria-selected', String(!isSignup));
  $('signup-tab').setAttribute('aria-selected', String(isSignup));
  $('login-tab').tabIndex = isSignup ? -1 : 0;
  $('signup-tab').tabIndex = isSignup ? 0 : -1;
  $('signup-name-field').classList.toggle('hidden', !isSignup);
  $('signup-confirm-field').classList.toggle('hidden', !isSignup);
  $('forgot-password').classList.toggle('hidden', isSignup);
  authName.required = isSignup;
  authConfirmPassword.required = isSignup;
  authPassword.minLength = isSignup ? 8 : 0;
  authPassword.autocomplete = isSignup ? 'new-password' : 'current-password';
  $('auth-submit').innerHTML = isSignup ? 'Create account <span>→</span>' : 'Sign in <span>→</span>';
  authForm.setAttribute('aria-labelledby', isSignup ? 'signup-tab' : 'login-tab');
  authFeedback.textContent = '';
  authConfirmPassword.setCustomValidity('');
}

function enterPlanner(user) {
  document.body.classList.remove('auth-gate-active');
  document.body.classList.add('student-entered');
  $('student-welcome').classList.add('hidden');
  $('account-actions').classList.remove('hidden');
  $('account-name').textContent = user.name;
  $('student-greeting').textContent = `Welcome, ${user.name}`;
  document.title = `Maharashtra Trails | ${user.name}`;
  loadDestinations();
}

function showAuthGate(message = '') {
  document.body.classList.remove('student-entered');
  document.body.classList.add('auth-gate-active');
  $('student-welcome').classList.remove('hidden');
  $('account-actions').classList.add('hidden');
  $('student-greeting').textContent = '';
  document.title = 'Maharashtra Trails | Tourism Planner';
  authFeedback.textContent = message;
}

$('login-tab').addEventListener('click', () => setAuthMode('login'));
$('signup-tab').addEventListener('click', () => setAuthMode('signup'));

$('password-toggle').addEventListener('click', () => {
  const show = authPassword.type === 'password';
  authPassword.type = show ? 'text' : 'password';
  $('password-toggle').textContent = show ? 'Hide' : 'Show';
  $('password-toggle').setAttribute('aria-label', `${show ? 'Hide' : 'Show'} password`);
  $('password-toggle').setAttribute('aria-pressed', String(show));
});

authConfirmPassword.addEventListener('input', () => authConfirmPassword.setCustomValidity(''));
authPassword.addEventListener('input', () => authConfirmPassword.setCustomValidity(''));
authForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  authFeedback.textContent = '';
  if (authMode === 'signup' && authPassword.value !== authConfirmPassword.value) {
    authConfirmPassword.setCustomValidity('Passwords do not match.');
    authConfirmPassword.reportValidity();
    authConfirmPassword.focus();
    return;
  }
  authConfirmPassword.setCustomValidity('');
  const isSignup = authMode === 'signup';
  const submit = $('auth-submit');
  const payload = {
    email: authEmail.value.trim(),
    password: authPassword.value,
  };
  if (isSignup) payload.name = authName.value.trim();
  submit.disabled = true;
  submit.textContent = isSignup ? 'Creating account…' : 'Signing in…';
  try {
    const user = await getJson(`${API}/auth/${isSignup ? 'register' : 'login'}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    authForm.reset();
    setAuthMode('login');
    enterPlanner(user);
  } catch (error) {
    authFeedback.textContent = error.message;
  } finally {
    submit.disabled = false;
    submit.innerHTML = authMode === 'signup' ? 'Create account <span>→</span>' : 'Sign in <span>→</span>';
  }
});

$('forgot-password').addEventListener('click', () => {
  authFeedback.textContent = 'Password reset is not configured because this local project has no email service yet.';
});

$('logout-button').addEventListener('click', async () => {
  try {
    await getJson(`${API}/auth/logout`, { method: 'POST' });
    csrfToken = null;
    showAuthGate('You have been signed out.');
  } catch (error) {
    if (error.status === 401) {
      csrfToken = null;
      showAuthGate('Your session has ended. Sign in again.');
    } else {
      toast(error.message);
    }
  }
});

async function restoreSession() {
  try {
    await getCsrfToken();
    const user = await getJson(`${API}/auth/me`);
    enterPlanner(user);
  } catch (error) {
    if (error.status === 401) {
      showAuthGate();
    } else {
      showAuthGate('Could not reach the authentication service. Start the Spring Boot app and refresh.');
    }
  }
}

setAuthMode('login');
restoreSession();
