# Destination photo credits

Each destination card uses a locally stored photograph from Wikimedia Commons. Photo authors and licensing vary by file; please retain these credits when reusing the project.

| Destination | File / author | License | Source |
|---|---|---|---|
| Mumbai destination card and login page | mumbai.jpg — Shrilekhdoctor | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Gateway_of_india_mumbai_in_september.jpg) |
| Pune | pune.jpg — Deepshinde | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Shaniwar_Wada_pune,_maharashtra.jpg) |
| Matheran | matheran.jpg — Udaykumar PR | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Matheran,_Maharashtra,_India_-_panoramio.jpg) |
| Lonavala | lonavala.jpg — Udaykumar PR | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Kapol_Resort,_Lonavala,Pune,Maharashtra_-_panoramio_(2).jpg) |
| Khandala | khandala.jpg — Author as listed on Commons | [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/) | [Commons file page](https://commons.wikimedia.org/wiki/File:Khandala-3.jpg) |
| Mahabaleshwar | mahabaleshwar.jpg — Rangan Datta Wiki | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Sunset_Dhom_Lake,_Mahabaleshwar_03.jpg) |
| Panchgani | panchgani.jpg — https://www.flickr.com/photos/bbalaji/ | [CC BY 2.0](https://creativecommons.org/licenses/by/2.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:View_from_Panchgani,_Maharashtra.jpg) |
| Nashik | nashik.jpg — World8115 | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Ram_Ghat,_Nashik,_Maharashtra.jpg) |
| Shirdi | shirdi.jpg — Photographer in Shirdi, India | Public domain | [Commons file page](https://commons.wikimedia.org/wiki/File:Shirdi_Sai_Baba.jpg) |
| Alibaug | alibaug.jpg — Gayatri Priyadarshini | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Alibaug_beach_sun_set_scene.jpg) |
| Murud | murud.jpg — Dr. Raju Kasambe | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Murud-Janjira_Fort_near_Murud_Raigad_Maharashtra_DPP_0093_(2).JPG) |
| Harihareshwar | harihareshwar.jpg — Siddhesh Mangela | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Harihareshwar,raigad_-_panoramio_(1).jpg) |
| Ganpatipule | ganpatipule.jpg — AmitUdeshi | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:In_The_Temple_Premises_Of_Lord_Ganesha_Swayambhu_At_Ganpatipule10.JPG) |
| Ratnagiri | ratnagiri.jpg — Omar AV | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Ratnadurg_Fort_-_panoramio.jpg) |
| Tarkarli | tarkarli.jpg — Ankur P | [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Beaches_in_India,_Tarkarli_Maharashtra_2012.jpg) |
| Malvan | malvan.jpg — Sneyo | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Small_island_at_malvan_sea.jpg) |
| Kolhapur | kolhapur.jpg — A.Murali | [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en) | [Commons file page](https://commons.wikimedia.org/wiki/File:Mahalaxmi_Temple,_Kolhapur,_Maharashtra_11.jpg) |
| Nagpur | nagpur.jpg — Ganesh Dhamodkar | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Trisaran_and_Panchsheel_at_Deekshabhoomi_Nagpur.jpg) |
| Amravati | amravati.jpg — Ganesh Dhamodkar | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Congress_Bhavan_Amravati_Maharashtra.jpg) |
| Chhatrapati Sambhajinagar | chhatrapati-sambhajinagar.jpg — Anjan Kumar Kundu | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:BIBI_KA_MAQBARA,_Begumpura,_Chhatrapati_Sambhajinagar,_Maharashtra_02.jpg) |
| Ajanta Caves | ajanta-caves.jpg — Amitabha Gupta | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Buddhist_Monks_inside_premises_of_Ajanta_Caves,_Maharashtra,_India_19.jpg) |
| Ellora Caves | ellora-caves.jpg — Amitabha Gupta | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Cave_no_19B,_Ellora_Caves,_Maharashtra,_India_01.jpg) |
| Shani Shingnapur | shani-shingnapur.jpg — K.Venkataramana | [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en) | [Commons file page](https://commons.wikimedia.org/wiki/File:Navagraha_mandapam_(Full_view),_Shani_temple,_Shani_shingnapur,_Maharashtra.jpg) |
| Bhimashankar | bhimashankar.jpg — ସୁରଥ କୁମାର ପାଢ଼ୀ | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Bhimashankar_temple,_Maharashtra.JPG) |
| Trimbakeshwar | trimbakeshwar.jpg — Abhideo21 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Trimbakeshwar_Temple-Nashik-Maharashtra-1.jpg) |
| Igatpuri | igatpuri.jpg — Kashif Pathan | [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:(A)_view_of_Indian_Railways_near_Igatpuri_Maharashtra_India.jpg) |
| Bhandardara | bhandardara.jpg — Rohit Parte | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Bhandardara_LakeView.jpg) |
| Tadoba-Andhari Tiger Reserve | tadoba-andhari-tiger-reserve.jpg — Dibyendu Ash | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:White-eyed-Buzzard_Tadoba-Andhari-Tiger-Reserve_Maharashtra_India_30.12.2012.jpg) |
| Pench National Park - Maharashtra | pench-national-park-maharashtra.jpg — Rohit Sharma | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Indian_Peacock_courtship_display_at_Pench_national_park_(April,_2024)_08.jpg) |
| Torna Fort | torna-fort.jpg — Vaibhavthegreat | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:View_While_Climbing_Torna_Fort.jpg) |
| Raigad Fort | raigad-fort.jpg — Yash ahire77 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Entrance_of_Raigad_Fort,_Raigad_district,_Maharashtra,_India_(2018).jpg) |
| Pratapgad Fort | pratapgad-fort.jpg — सुबोध कुलकर्णी | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Pratapgad_fort_in_Maharashtra.jpg) |
| Sinhagad Fort | sinhagad-fort.jpg — Mayurthopate | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Sinhagad_fort_in_pune_(12).jpg) |
| Devkund Waterfall | devkund-waterfall.jpg — Wiki GSD | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Devkund_Waterfall.JPG) |
| Lonar Lake | lonar-lake.jpg — Amitabha Gupta | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Shri_Kumareshwar_Temple,_Lonar_Lake,_Maharashtra,_India_05.jpg) |
| Amboli | amboli.jpg — Viraj J Narkar | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Amboli_Waterfall,Sindhudurg(Maharashtra).jpg) |
| Sawantwadi | sawantwadi.jpg — Coolbreeze9182 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Sawantwadi_Palace_Sawantwadi_Maharashtra.jpg) |
| Jawhar | jawhar.jpg — Star Dust H | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Hiradpada_Waterfall,_Jawhar.jpg) |
| Akkalkot | akkalkot.jpg — Varun sakpal | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Shree_swami_samarth_Akkalkot.jpg) |
| Nanded | nanded.jpg — Jaspal singh | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Hazur_Sahib,_Nanded,_Maharashtra,_September_2012.jpg) |
| Tuljapur | tuljapur.jpg — Glasreifen | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Indien2012_1215_Tuljapur_Bhavani_Temple_Eingangstor.jpg) |
| Pandharpur | pandharpur.jpg — A.Murali | [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en) | [Commons file page](https://commons.wikimedia.org/wiki/File:Pandurang_vitthal_Temple,_Pandharpur,_Maharashtra_01.jpg) |
| Solapur | solapur.jpg — Uddhavghodake | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Siddheshwar_temple_Solapur.jpg) |
| Wardha | wardha.jpg — Sajeevk | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Sevagram_Ashram,_Wardha.jpg) |
| Melghat | melghat.jpg — Dr. Raju Kasambe | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Forest_Owlet_(Heteroglaux_blewitti,_Athene_blewitti)_in_Melghat_Tiger_Reserve_Maharashtra_(2).jpg) |
| Chikhaldara | chikhaldara.jpg — Dhirajphotography | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Reflection_in_chikhaldara_Maharashtra.jpg) |
| Dapoli | dapoli.jpg — Nilesh.shintre | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Anjarle_beach_in_Konkan_near_Dapoli_,_Maharashtra,India.jpg) |
| Diveagar | diveagar.jpg — Ankur P | [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Diveagar_beach.jpg) |
| Kamshet | kamshet.jpg — Hankareakshaye | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Scenery_at_kamshet.jpg) |
| Lavasa | lavasa.jpg — Mayur239 | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Commons file page](https://commons.wikimedia.org/wiki/File:Lavasa_City.JPG) |
| Homepage hero — Bhimashankar Wildlife Sanctuary | hero-bhimashankar.jpg — Nikhil More | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) | [Commons file page](https://commons.wikimedia.org/wiki/File:Monsoon_Maharashtra_India_Rain_Landscape_(1)_16.jpg) |

The hero photo is displayed with a responsive crop and CSS gradient overlay. Please retain the attribution and follow the linked share-alike license when reusing the adapted image.
