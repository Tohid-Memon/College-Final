(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const state = { destinations: [], origin: null, nearby: [], selected: new Set(), map: null, tileLayer: null, resultLayer: null, routeLayer: null, route: null };
  let csrfToken = null;
  const escapeHtml = (value = '') => String(value).replace(/[&<>"']/g, (ch) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
  const km = (meters) => `${(Number(meters || 0) / 1000).toFixed(1)} km`;
  const minutes = (seconds) => {
    const mins = Math.round(Number(seconds || 0) / 60);
    return mins < 60 ? `${mins} min` : `${Math.floor(mins / 60)} hr ${mins % 60} min`;
  };

  function setStatus(message, kind = '') {
    const el = $('route-status');
    el.textContent = message;
    el.className = `route-status${kind ? ` is-${kind}` : ''}`;
  }

  function showAuthMessage(message = 'Sign in to use your saved planner session.') {
    $('auth-message').classList.remove('hidden');
    $('auth-message').firstChild.textContent = `${message} `;
    $('find-nearby').disabled = true;
    $('search-custom-place').disabled = true;
    $('use-location').disabled = true;
    $('build-route').disabled = true;
    setStatus('Sign in on the main planner, then return here.', 'error');
  }

  async function getCsrfToken() {
    if (csrfToken) return csrfToken;
    const response = await fetch('/api/auth/csrf', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.token) throw new Error(data.message || 'Could not start a secure session. Refresh the page and try again.');
    csrfToken = data.token;
    return csrfToken;
  }

  async function api(path, options = {}) {
    const method = (options.method || 'GET').toUpperCase();
    const headers = { Accept: 'application/json', ...(options.headers || {}) };
    if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) headers['X-XSRF-TOKEN'] = await getCsrfToken();
    const response = await fetch(path, { ...options, method, headers, credentials: 'same-origin' });
    if (response.status === 204) return null;
    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(body.message || 'The request did not complete. Please try again.');
      error.status = response.status;
      if (response.status === 401) showAuthMessage();
      throw error;
    }
    return body;
  }

  function initMap() {
    if (state.map || !window.L) return;
    state.map = L.map('route-map', { scrollWheelZoom: false, preferCanvas: true }).setView([19.4, 75.5], 6);
    state.tileLayer = L.tileLayer('/api/maps/tiles/{z}/{x}/{y}.png', {
      minZoom: 5,
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',
      crossOrigin: true,
    }).addTo(state.map);
    state.resultLayer = L.layerGroup().addTo(state.map);
    state.routeLayer = L.layerGroup().addTo(state.map);
    state.tileLayer.on('tileerror', () => { $('map-caption').textContent = 'Map tiles are temporarily unavailable; the stop list remains usable.'; });
    setTimeout(() => state.map.invalidateSize(), 120);
  }

  function mapPoint(latitude, longitude, label, number, isStart = false) {
    const icon = L.divIcon({ className: '', html: `<span class="map-number-marker${isStart ? ' map-start-marker' : ''}">${escapeHtml(number)}</span>`, iconSize: [25, 25], iconAnchor: [12, 12] });
    return L.marker([latitude, longitude], { icon, title: label, keyboard: true }).bindTooltip(escapeHtml(label), { direction: 'top', offset: [0, -10] });
  }

  function fitMapToPoints(points) {
    if (!points.length || !state.map) return;
    const bounds = L.latLngBounds(points.map((point) => [point.latitude, point.longitude]));
    if (bounds.isValid()) {
      state.map.fitBounds(bounds.pad(points.length === 1 ? 0.08 : 0.18), { maxZoom: 13 });
      requestAnimationFrame(() => state.map?.invalidateSize({ pan: false }));
    }
  }

  function drawNearby() {
    initMap();
    state.routeLayer.clearLayers();
    state.resultLayer.clearLayers();
    const points = [];
    if (state.origin) {
      mapPoint(state.origin.latitude, state.origin.longitude, `Start: ${state.origin.name}`, 'S', true).addTo(state.resultLayer);
      L.circle([state.origin.latitude, state.origin.longitude], { radius: Number($('search-radius').value) * 1000, color: '#79a56e', weight: 1, fillColor: '#d9edc8', fillOpacity: .12 }).addTo(state.resultLayer);
      points.push(state.origin);
    }
    state.nearby.forEach((place, index) => {
      const selected = state.selected.has(place.id);
      const label = `${place.name}${selected ? ', selected stop' : ''}`;
      mapPoint(place.latitude, place.longitude, label, String(index + 1)).addTo(state.resultLayer);
      points.push(place);
    });
    fitMapToPoints(points);
    $('map-caption').textContent = state.nearby.length ? `${state.nearby.length} mapped place${state.nearby.length === 1 ? '' : 's'} near ${state.origin?.name || 'your start'}.` : 'Nearby places will be shown on the map.';
  }

  function renderNearby() {
    $('nearby-count').textContent = state.nearby.length ? `${state.nearby.length} mapped place${state.nearby.length === 1 ? '' : 's'}, sorted by distance` : 'No mapped places were found in this radius.';
    $('nearby-results').innerHTML = state.nearby.length ? state.nearby.map((place) => `
      <article class="nearby-card">
        <div class="nearby-card-top">
          <input type="checkbox" value="${escapeHtml(place.id)}" aria-label="Select ${escapeHtml(place.name)}" ${state.selected.has(place.id) ? 'checked' : ''} />
          <div class="nearby-card-main"><strong>${escapeHtml(place.name)}</strong>
            <div class="nearby-card-meta"><span>${escapeHtml(place.category)}</span><span>${Number(place.distanceKm).toFixed(1)} km away</span></div>
          </div>
          <a href="${escapeHtml(place.mapUrl)}" target="_blank" rel="noopener noreferrer" aria-label="View ${escapeHtml(place.name)} on OpenStreetMap">Map ↗</a>
        </div>
      </article>`).join('') : '<p class="empty-state">Try a larger radius, or choose another starting point. Nearby results come from community-maintained OpenStreetMap data, so coverage varies by area.</p>';
    $('nearby-results').querySelectorAll('input[type=checkbox]').forEach((checkbox) => {
      checkbox.addEventListener('change', () => {
        if (checkbox.checked) {
          if (state.selected.size >= 8) { checkbox.checked = false; setStatus('Choose up to 8 stops for a single route.', 'error'); return; }
          state.selected.add(checkbox.value);
        } else state.selected.delete(checkbox.value);
        state.route = null;
        $('route-output').classList.add('hidden');
        $('route-output').classList.remove('route-output-error');
        updateSelection();
        drawNearby();
      });
    });
    updateSelection();
    drawNearby();
  }

  function updateSelection() {
    $('selected-count').textContent = `${state.selected.size} / 8`;
    $('build-route').disabled = state.selected.size === 0 || !state.origin;
    $('nearby-results').querySelectorAll('input[type=checkbox]').forEach((checkbox) => {
      checkbox.disabled = !checkbox.checked && state.selected.size >= 8;
    });
  }

  async function loadNearby(origin, radiusKm) {
    state.origin = origin;
    state.nearby = [];
    state.selected.clear();
    state.route = null;
    $('route-output').classList.add('hidden');
    $('route-output').classList.remove('route-output-error');
    $('origin-summary').textContent = `Starting near ${origin.name} · ${origin.latitude.toFixed(4)}, ${origin.longitude.toFixed(4)}`;
    $('origin-summary').classList.remove('hidden');
    $('nearby-results').innerHTML = '<p class="empty-state">Searching the nearby map data…</p>';
    $('nearby-count').textContent = 'Searching…';
    $('build-route').disabled = true;
    setStatus('Finding mapped attractions and points of interest…');
    try {
      const params = new URLSearchParams({ latitude: origin.latitude, longitude: origin.longitude, radiusKm: String(radiusKm), placeName: origin.name });
      state.nearby = await api(`/api/maps/nearby?${params}`);
      renderNearby();
      setStatus(state.nearby.length ? `Found ${state.nearby.length} nearby place${state.nearby.length === 1 ? '' : 's'}. Select up to 8 stops.` : 'No mapped results here yet. Try a wider search radius.', state.nearby.length ? 'success' : '');
    } catch (error) {
      const retryable = error.status === 502 || error.status === 503 || error.status === 504;
      $('nearby-results').innerHTML = `<p class="empty-state">${escapeHtml(error.message)}</p>${retryable ? '<button id="retry-nearby" class="quiet-button nearby-retry-button" type="button">Try nearby search again</button>' : ''}`;
      $('retry-nearby')?.addEventListener('click', () => {
        if (state.origin) loadNearby(state.origin, Number($('search-radius').value));
      }, { once: true });
      $('nearby-count').textContent = 'Search could not be completed.';
      setStatus(error.message, 'error');
    }
  }

  async function searchFromDestination(destinationId) {
    const destination = state.destinations.find((item) => Number(item.id) === Number(destinationId));
    if (!destination) { setStatus('Choose a destination from the list first.', 'error'); return; }
    $('destination-select').value = String(destination.id);
    $('custom-location').value = '';
    setStatus(`Locating ${destination.name}…`);
    try {
      const query = [destination.name, destination.district, 'Maharashtra', 'India'].filter(Boolean).join(', ');
      const place = await api(`/api/maps/geocode?query=${encodeURIComponent(query)}`);
      await loadNearby({ name: destination.name, latitude: place.latitude, longitude: place.longitude }, Number($('search-radius').value));
    } catch (error) { setStatus(error.message, 'error'); }
  }

  async function searchCustomPlace() {
    const query = $('custom-location').value.trim();
    if (!query) { setStatus('Enter a place name before searching.', 'error'); $('custom-location').focus(); return; }
    setStatus(`Locating ${query}…`);
    try {
      const place = await api(`/api/maps/geocode?query=${encodeURIComponent(query)}`);
      const shortName = place.displayName.split(',')[0] || query;
      $('destination-select').value = '';
      await loadNearby({ name: shortName, latitude: place.latitude, longitude: place.longitude }, Number($('search-radius').value));
    } catch (error) { setStatus(error.message, 'error'); }
  }

  function useCurrentLocation() {
    if (!navigator.geolocation) { setStatus('This browser does not provide location access. Search for a place instead.', 'error'); return; }
    setStatus('Waiting for your location permission…');
    navigator.geolocation.getCurrentPosition(async (position) => {
      const { latitude, longitude } = position.coords;
      $('destination-select').value = '';
      $('custom-location').value = '';
      try {
        await loadNearby({ name: 'Your current location', latitude, longitude }, Number($('search-radius').value));
      } catch (error) { setStatus(error.message, 'error'); }
    }, (error) => {
      const message = error.code === 1 ? 'Location access was not allowed. Choose or search for a place instead.' : 'Your location could not be read. Choose or search for a place instead.';
      setStatus(message, 'error');
    }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 300000 });
  }

  async function buildRoute() {
    const selected = state.nearby.filter((place) => state.selected.has(place.id));
    if (!state.origin || !selected.length) return;
    $('build-route').disabled = true;
    $('build-route').textContent = 'Finding the closest-next route…';
    $('route-output').classList.remove('hidden');
    $('route-output').classList.remove('route-output-error');
    $('route-output').textContent = 'Checking road travel times between your selected places…';
    setStatus('Checking route options between your selected places…');
    try {
      const route = await api('/api/maps/route', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ origin: { name: state.origin.name, latitude: state.origin.latitude, longitude: state.origin.longitude }, stops: selected }),
      });
      state.route = route;
      renderRoute(route);
      setStatus('Route ready. The closest reachable stop is visited next.', 'success');
    } catch (error) {
      $('route-output').textContent = error.message;
      $('route-output').classList.add('route-output-error');
      setStatus(error.message, 'error');
    } finally {
      $('build-route').disabled = state.selected.size === 0;
      $('build-route').innerHTML = 'Build closest-next route <span>→</span>';
    }
  }

  function renderRoute(route) {
    $('route-output').classList.remove('hidden', 'route-output-error');
    const walking = route.mode === 'walking-estimate';
    const travelLabel = walking ? 'straight-line walking estimate' : 'estimated road travel';
    const total = `${km(route.totalDistanceMeters)} · about ${minutes(route.totalDurationSeconds)} ${travelLabel}`;
    const stops = route.stops || [];
    const html = stops.map((stop, index) => `
      <li class="route-stop"><span class="route-stop-number">${index === 0 ? 'S' : index}</span><div><strong>${escapeHtml(stop.name)}</strong>
        <small>${index === 0 ? 'Starting point' : `${escapeHtml(stop.category)} · ${km(stop.legDistanceMeters)} · about ${minutes(stop.legDurationSeconds)} ${walking ? 'walking estimate' : 'by road'} from previous stop`}</small></div></li>`).join('');
    const origin = stops[0]; const last = stops[stops.length - 1];
    const maps = new URL('https://www.google.com/maps/dir/');
    maps.searchParams.set('api', '1');
    maps.searchParams.set('origin', `${origin.latitude},${origin.longitude}`);
    maps.searchParams.set('destination', `${last.latitude},${last.longitude}`);
    maps.searchParams.set('travelmode', walking ? 'walking' : 'driving');
    if (stops.length > 2) maps.searchParams.set('waypoints', stops.slice(1, -1).map((stop) => `${stop.latitude},${stop.longitude}`).join('|'));
    const directionsLabel = walking ? 'Check walking directions in Google Maps' : 'Open driving directions in Google Maps';
    $('route-output').innerHTML = `<h3>Your route order</h3><p class="route-total">${escapeHtml(total)}</p><p class="route-note${walking ? ' is-walking' : ''}">${escapeHtml(route.note || '')}</p><ol class="route-stop-list">${html}</ol><a class="directions-link" href="${escapeHtml(maps.toString())}" target="_blank" rel="noopener noreferrer">${directionsLabel} ↗</a>`;
    state.routeLayer.clearLayers();
    if (route.geometry && state.map) {
      L.geoJSON(route.geometry, { style: { color: '#24634a', weight: 5, opacity: .88, lineCap: 'round', lineJoin: 'round' } }).addTo(state.routeLayer);
    }
    stops.forEach((stop, index) => mapPoint(stop.latitude, stop.longitude, stop.name, index === 0 ? 'S' : String(index), index === 0).addTo(state.routeLayer));
    fitMapToPoints(stops);
    $('map-caption').textContent = `${stops.length - 1} selected stop${stops.length === 2 ? '' : 's'} in closest-next order.`;
    $('route-output').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function dateLocal(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }

  function addDays(date, days) { const result = new Date(date); result.setDate(result.getDate() + days); return result; }

  function initializeHotelDates() {
    const checkin = addDays(new Date(), 7);
    const checkout = addDays(checkin, 2);
    $('hotel-checkin').value = dateLocal(checkin);
    $('hotel-checkout').value = dateLocal(checkout);
    $('hotel-checkin').min = dateLocal(new Date());
    $('hotel-checkout').min = dateLocal(addDays(checkin, 1));
    $('hotel-checkin').addEventListener('change', () => {
      const min = dateLocal(addDays(new Date(`${$('hotel-checkin').value}T00:00:00`), 1));
      $('hotel-checkout').min = min;
      if ($('hotel-checkout').value < min) $('hotel-checkout').value = min;
    });
  }

  function bookingSearch(event) {
    event.preventDefault();
    const chosen = state.origin?.name || $('custom-location').value.trim() || $('destination-select').selectedOptions[0]?.textContent || '';
    if (!chosen || chosen.includes('Loading')) { $('hotel-search-status').textContent = 'Choose or search a starting place before checking stays.'; return; }
    const checkin = $('hotel-checkin').value;
    const checkout = $('hotel-checkout').value;
    if (!checkin || !checkout || checkout <= checkin) { $('hotel-search-status').textContent = 'Choose a check-out date after check-in.'; return; }
    const guests = Math.max(1, Math.min(30, Number($('hotel-guests').value) || 2));
    const params = new URLSearchParams({ ss: chosen, checkin, checkout, group_adults: String(guests), no_rooms: '1', group_children: '0', selected_currency: 'INR', lang: 'en-us' });
    const url = `https://www.booking.com/searchresults.html?${params.toString()}`;
    window.open(url, '_blank', 'noopener,noreferrer');
    $('hotel-search-status').textContent = `Opened live Booking.com results for ${chosen}. Confirm availability, final total, taxes, room type and cancellation terms on the provider page.`;
  }

  async function initialize() {
    initializeHotelDates();
    $('search-custom-place').addEventListener('click', searchCustomPlace);
    $('custom-location').addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); searchCustomPlace(); } });
    $('find-nearby').addEventListener('click', () => {
      if (state.origin) loadNearby(state.origin, Number($('search-radius').value));
      else searchFromDestination($('destination-select').value);
    });
    $('destination-select').addEventListener('change', () => { state.origin = null; state.nearby = []; state.selected.clear(); $('origin-summary').classList.add('hidden'); $('nearby-results').innerHTML = '<p class="empty-state">Press “Find nearby attractions” to search this place.</p>'; $('nearby-count').textContent = 'Nearby attractions will appear here.'; updateSelection(); });
    $('use-location').addEventListener('click', useCurrentLocation);
    $('search-radius').addEventListener('change', () => { if (state.origin) setStatus('Radius updated. Press “Find nearby attractions” to run the new search.'); });
    $('build-route').addEventListener('click', buildRoute);
    $('hotel-search-form').addEventListener('submit', bookingSearch);
    try {
      await api('/api/auth/me');
      initMap();
      const data = await api('/api/destinations');
      state.destinations = data;
      $('destination-select').innerHTML = '<option value="">Choose a Maharashtra destination</option>' + data.map((destination) => `<option value="${Number(destination.id)}">${escapeHtml(destination.name)} — ${escapeHtml(destination.district || 'Maharashtra')}</option>`).join('');
      const destinationId = new URLSearchParams(window.location.search).get('destinationId');
      if (destinationId && state.destinations.some((destination) => String(destination.id) === destinationId)) await searchFromDestination(destinationId);
    } catch (error) {
      if (error.status === 401) return;
      setStatus(error.message, 'error');
    }
  }

  initialize();
})();
